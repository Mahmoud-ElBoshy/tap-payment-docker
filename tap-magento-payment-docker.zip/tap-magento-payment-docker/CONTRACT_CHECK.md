# Contract check against Tap's documentation

Cross-checked against the Charges and Authorize reference pages from the brief, plus the Tap guides they link to
(Webhook, Redirect, Idempotency) and the API authentication page.

## Verified (matches the docs)
- Base URL `https://api.tap.company/v2`, header `Authorization: Bearer <secret key>`.
- `POST /v2/charges` and `POST /v2/authorize` payloads: `amount`, `currency`, `threeDSecure`, `customer_initiated`,
  `save_card`, `description`, `metadata`, `reference.{transaction,order}`, `receipt`, `customer`, `source.id`,
  `post.url`, `redirect.url`. `redirect.url` is mandatory for 3DS.
- Response: `id` (`chg_` / `auth_`), `status`, `transaction.url` to redirect the buyer to.
- Return: Tap appends `tap_id` to `redirect.url`; the transaction is retrieved with `GET /v2/charges/{id}` or
  `GET /v2/authorize/{id}`.
- Charge statuses: INITIATED, ABANDONED, CANCELLED, FAILED, DECLINED, RESTRICTED, CAPTURED, VOID, TIMEDOUT, UNKNOWN;
  authorize adds AUTHORIZED. CAPTURED/AUTHORIZED are the success states; ABANDONED, CANCELLED, FAILED, DECLINED, RESTRICTED, VOID, TIMEDOUT and
  UNKNOWN are failures (the docs list UNKNOWN under "payment failed"); anything else (INITIATED, in-progress states
  such as Fawry's) is treated as pending.
- Tap recommends the webhook (post URL) as the sure way to learn the final status, and says it cannot post to localhost.

## Corrected after reading the docs
| Area | First draft | Documented | Now |
|---|---|---|---|
| Authorize source | `src_all` | "Authorize works only with credit cards"; hosted page = `src_card` | `src_card` in authorize mode, `src_all` in charge mode |
| `auto` (auto void/capture) | sent with `src_all` | "not applicable for src_all and src_card" (needs a token source) | not sent |
| Duplicate protection | none | `reference.idempotent`, same string within 24h returns the original response | sent (`txn_<order increment id>`) |
| Webhook authenticity | status re-fetched only | `hashstring` header = HMAC-SHA256 of `x_id...x_amount...x_currency...x_gateway_reference...x_payment_reference...x_status...x_created`, amount in currency decimals | validated (`HashString`), HTTP 401 on mismatch, then status re-fetched |

## Corrected after reading the test-data pages
- `UNKNOWN` was treated as pending; the Charges/Authorize pages list it as a failure, so the order is now canceled.
  (The sandbox triggers it with expiry `05/37`.)
- The README now has the shared sandbox keys (merchant `599424`) and a scenario table based on Tap's test cards: the
  expiry date selects the simulated outcome (`01/39` approved, `05/22` declined, `04/27` expired card, `08/28` timed out,
  `01/37`/`02/37` failures, `05/37` unknown), and enrolled cards trigger 3DS.