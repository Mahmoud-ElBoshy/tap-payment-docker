# Tap_Payment - Tap Payments gateway for Magento 2

Hosted-checkout redirect integration with the Tap REST API (`/v2/charges` or `/v2/authorize`).
Tested target: Magento 2.4.x, PHP 8.1+.

## Install

```bash
# copy this folder to app/code/Tap/Payment
bin/magento module:enable Tap_Payment
bin/magento setup:upgrade
bin/magento setup:di:compile        # production mode
bin/magento setup:static-content:deploy -f
bin/magento cache:flush
```

## Configure

Admin: **Stores > Configuration > Sales > Payment Methods > Tap Payments**

| Field | Type | Notes |
|---|---|---|
| Enable Gateway | Yes/No | shows/hides the method at checkout |
| Test Public Key | obscure (encrypted) | `pk_test_...`, from https://developers.tap.company/reference/testing-keys |
| Test Secret Key | obscure (encrypted) | `sk_test_...`, server-side only |
| Transaction Mode | Authorize / Charge | picks `/v2/authorize` or `/v2/charges` |
| Title, Debug Logging, Sort Order | extras | |

Keys use `Magento\Config\Model\Config\Backend\Encrypted` and are decrypted only in `Model\Config`.
`tap/payment/webhook` must be reachable from the internet (use ngrok on local).

## Flow

```
Place Order (Magento creates order: state new / status pending)
  -> tap-method.js afterPlaceOrder -> GET /tap/payment/redirect
       Client::createTransaction -> POST /v2/charges | /v2/authorize
         payload includes redirect.url = /tap/payment/response and post.url = /tap/payment/webhook
       redirect buyer to transaction.url (Tap hosted page)
  -> buyer pays -> Tap redirects to /tap/payment/response?tap_id=chg_...
       GET /v2/charges/{id} (verified server-side) -> PaymentProcessor
  -> Tap also POSTs /tap/payment/webhook (same PaymentProcessor, idempotent)

success: order Processing + transaction (chg_/auth_) in Sales > Transactions + success page
failed/declined/canceled: order Canceled + cart restored + redirect to cart with an error message
```

## Design notes (for the code walk-through)

- **Payment method** is a `Magento\Payment\Model\Method\Adapter` virtual type with a value-handler pool only
  (no gateway commands). Magento places the order; our controllers own the Tap call. See `etc/di.xml`.
- **Checkout UI**: `tap.js` registers the renderer, `tap-method.js` sets `redirectAfterPlaceOrder: false` and redirects
  to our controller in `afterPlaceOrder`.
- **Never trust the browser**: the return URL and webhook only give us a transaction id. `Client::retrieve()` fetches the
  real status with the secret key; the id is whitelisted by regex before being put in the request path.
- **One processor, two callers** (`PaymentProcessor`): return URL and webhook race. A lock (`LockManagerInterface`)
  serializes them and only orders in state `new` are changed, so processing twice is a no-op.
- **Charge vs Authorize**: charge -> `/v2/charges` with `src_all`, then `registerCaptureNotification` (invoice + capture
  transaction); authorize -> `/v2/authorize` with `src_card` (Tap: authorize works only with credit cards), then
  `registerAuthorizationNotification` (open auth transaction, capture later with the Charges API).
- **Idempotency**: `reference.idempotent` = `txn_<order>`; Tap returns the original response for 24h, so a double click or
  refresh on the redirect step cannot create a second charge.
- **Webhook security (two checks)**: the `hashstring` header is validated with Tap's official scheme
  (`HashString`), and the status is then re-fetched from Tap with the secret key.
- **Amount check**: verified amount + currency must equal the order, else the order is put on hold.
- **Logging**: `var/log/tap_payment.log`, ids and statuses only, no keys or card data.

## Sandbox credentials and test data

Source: https://developers.tap.company/reference/testing-keys and /testing-cards. Tap publishes shared TEST credentials
(and recommends your own test keys from the Tap dashboard, goSell > API Credentials):

| Field | Value |
|---|---|
| Test Merchant ID | `599424` |
| Test Public Key | `pk_test_EtHFV4BuPQokJT6jiROls87Y` |
| Test Secret Key | `sk_test_XKokBfNWv6FIYuTMg5sLPjhJ` |

Test cards (Visa/Mastercard work in both Charge and Authorize mode; use any future-looking CVV below):

| Scenario | Card | Expiry | CVV | Expected Tap result | Expected Magento result |
|---|---|---|---|---|---|
| Success, no 3DS | Visa `4012000033330026` | `01/39` | `100` | CAPTURED | order Processing, `chg_` transaction |
| Success, with 3DS | Visa `4508750015741019` or Mastercard `5123450000000008` | `01/39` | `100` | CAPTURED after 3DS | order Processing, `chg_` transaction |
| Declined | any test card | `05/22` | `100` | DECLINED | order Canceled, cart restored |
| Expired card | any test card | `04/27` | `100` | EXPIRED_CARD (failed) | order Canceled, cart restored |
| Timed out | any test card | `08/28` | `100` | TIMEDOUT | order Canceled, cart restored |
| Acquirer error / unspecified | any test card | `01/37` / `02/37` | `100` | failed | order Canceled, cart restored |
| Unknown | any test card | `05/37` | `100` | UNKNOWN (the docs list it as a failure) | order Canceled, cart restored |
| Authorize mode success | Visa `4012000033330026` | `01/39` | `100` | AUTHORIZED | order Processing, `auth_` transaction |

The expiry date selects the simulated outcome. Local methods (KNET `8888880000000001`, Benefit, QPay...) appear on the hosted
page only in Charge mode with `src_all` and depend on the merchant's enabled methods and currency (for example KWD for KNET).

## Manual test checklist (sandbox)

1. Admin: enable the gateway, paste the test keys above, pick Charge, flush the cache.
2. Place an order (Visa `4012000033330026`, `01/39`, CVV `100`) -> order Processing, transaction `chg_...` under
   Sales > Orders > Transactions, success page.
3. Repeat with `05/22` (declined) and press Cancel on the hosted page -> order Canceled, cart restored, error shown on the cart page.
4. Repeat with the 3DS card `4508750015741019` -> 3DS step on the hosted page, then success.
5. Switch Transaction Mode to Authorize and repeat -> `auth_...` transaction, order Processing.
6. Webhooks need a public HTTPS URL (Tap cannot post to localhost): use the ngrok profile from `DOCKER.md` and check
   `var/log/tap_payment.log` for `tap.webhook.handled`. A webhook with a wrong `hashstring` must get HTTP 401; a replayed
   valid webhook returns `outcome: success` and changes nothing.
7. Egypt: with `src_all`, Fawry (cash wallet) can leave the charge in an in-progress state; the order stays `new` and the
   webhook finalizes it (or cancels it on ABANDONED/TIMEDOUT after Tap's 30 minute default expiry).
8. Double click on "Place Order"/refresh on the redirect step -> same hosted page (idempotent), only one transaction.

## Known limitations

- Test keys only (as per brief); live keys would be additional config fields.
- The order confirmation email is sent by Magento at placement (before payment). Delay it with an observer or
  `sales_email/general/async_sending` if needed.
- If the buyer never returns and the webhook cancels the order, the cart is not restored (no session available).
- Capture/void/refund from the admin are not implemented (out of scope).
- Nothing was run against the live Tap sandbox from this environment; see `CONTRACT_CHECK.md` for what was verified in the docs.
- Authorize mode does not send Tap's `auto` capture/void object (not applicable with hosted-page sources); the
  authorization lasts for the card scheme's period, and capture/void are out of scope.
