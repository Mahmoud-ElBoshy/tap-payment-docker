#!/usr/bin/env bash
# Runs inside the php container as www-data. Idempotent: safe to re-run.
set -euo pipefail
cd /var/www/html

# Composer 2.9+ refuses packages that have security advisories, and the 2.4.7 base release has some.
# This is a disposable LOCAL sandbox, so advisory blocking is turned off for it (never do this in production).
export COMPOSER_HOME="${COMPOSER_HOME:-/tmp/composer}"
mkdir -p "$COMPOSER_HOME"
composer config -g policy.advisories.block false

if [ -z "${MAGENTO_PUBLIC_KEY:-}" ] || [ -z "${MAGENTO_PRIVATE_KEY:-}" ]; then
  echo "MAGENTO_PUBLIC_KEY / MAGENTO_PRIVATE_KEY are missing in .env (Adobe Commerce Marketplace access keys)." >&2
  exit 1
fi

# 1) Download Magento into the (empty) volume.
if [ ! -f bin/magento ]; then
  composer create-project --repository-url=https://repo.magento.com/ \
    "magento/project-community-edition=${MAGENTO_VERSION}" /tmp/magento --no-interaction
  rsync -a /tmp/magento/ /var/www/html/
  rm -rf /tmp/magento
fi

# 2) Install Magento.
if [ ! -f app/etc/env.php ]; then
  bin/magento setup:install \
    --base-url="${BASE_URL}" \
    --db-host=db --db-name=magento --db-user=magento --db-password=magento \
    --search-engine=opensearch --opensearch-host=opensearch --opensearch-port=9200 \
    --opensearch-index-prefix=magento2 --opensearch-timeout=15 \
    --admin-firstname=Admin --admin-lastname=Admin --admin-email=admin@example.com \
    --admin-user=admin --admin-password="${ADMIN_PASSWORD}" \
    --backend-frontname=admin \
    --language=en_US --currency=USD --timezone=Africa/Cairo \
    --use-rewrites=1 --cleanup-database
fi

# 3) Developer conveniences: no 2FA for the admin login, developer mode.
bin/magento module:disable Magento_AdminAdobeImsTwoFactorAuth Magento_TwoFactorAuth || true
bin/magento deploy:mode:set developer --skip-compilation || true

# 4) Install the Tap module from the mounted folder as a symlinked composer path package.
composer config repositories.tap-payment '{"type":"path","url":"/opt/tap-payment","options":{"symlink":true}}'
composer require tap/module-payment:@dev --no-interaction
bin/magento module:enable Tap_Payment
bin/magento setup:upgrade
bin/magento cache:flush

echo
echo "Storefront: ${BASE_URL}"
echo "Admin:      ${BASE_URL}admin   (user: admin / password: ${ADMIN_PASSWORD})"
echo "Next: Stores > Configuration > Sales > Payment Methods > Tap Payments"
