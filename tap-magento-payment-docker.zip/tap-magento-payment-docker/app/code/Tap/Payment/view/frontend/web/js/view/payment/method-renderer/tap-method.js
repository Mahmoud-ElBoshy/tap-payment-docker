/**
 * Tap payment method renderer.
 * After Magento places the order (state "new") we do NOT go to the default success page; we send the buyer to
 * tap/payment/redirect, which creates the Tap transaction and redirects to the hosted payment page.
 */
define([
    'Magento_Checkout/js/view/payment/default',
    'mage/url'
], function (Component, url) {
    'use strict';

    return Component.extend({
        defaults: {
            template: 'Tap_Payment/payment/tap',
            redirectAfterPlaceOrder: false
        },

        afterPlaceOrder: function () {
            window.location.replace(url.build('tap/payment/redirect'));
        }
    });
});
