<?php
declare(strict_types=1);

namespace Tap\Payment\Controller\Payment;

use Magento\Framework\App\CsrfAwareActionInterface;
use Magento\Framework\App\Action\HttpPostActionInterface;
use Magento\Framework\App\Request\Http as HttpRequest;
use Magento\Framework\App\Request\InvalidRequestException;
use Magento\Framework\App\RequestInterface;
use Magento\Framework\Controller\Result\Json;
use Magento\Framework\Controller\Result\JsonFactory;
use Psr\Log\LoggerInterface;
use Tap\Payment\Model\Api\Client;
use Tap\Payment\Model\Config;
use Tap\Payment\Model\HashString;
use Tap\Payment\Model\PaymentProcessor;

/**
 * Request post URL (IPN). Tap posts the transaction object here.
 * Two independent checks before an order is touched:
 *  1. the `hashstring` header (HMAC-SHA256 with the secret key, Tap's official scheme) must match the body;
 *  2. the real status is re-fetched from Tap with the secret key (the body is only used to learn the id).
 * Returns 200 when handled, 401 for a bad signature, 500 on other errors so Tap can retry.
 */
class Webhook implements HttpPostActionInterface, CsrfAwareActionInterface
{
    public function __construct(
        private readonly HttpRequest $request,
        private readonly Client $client,
        private readonly PaymentProcessor $processor,
        private readonly Config $config,
        private readonly HashString $hashString,
        private readonly JsonFactory $jsonFactory,
        private readonly LoggerInterface $logger
    ) {
    }

    public function execute(): Json
    {
        $result = $this->jsonFactory->create();
        $body = json_decode((string) $this->request->getContent(), true);
        $tapId = is_array($body) ? (string) ($body['id'] ?? '') : '';

        $posted = $this->request->getHeader('hashstring');
        if (!is_array($body) || !$this->hashString->validate($body, is_string($posted) ? $posted : '', $this->config->getSecretKey())) {
            $this->logger->warning('tap.webhook.bad_hashstring', ['tap_id' => $tapId]);

            return $result->setHttpResponseCode(401)->setData(['status' => 'invalid signature']);
        }

        try {
            $tapData = $this->client->retrieve($tapId);
            $outcome = $this->processor->process((string) ($tapData['reference']['order'] ?? ''), $tapData);

            $this->logger->info('tap.webhook.handled', ['tap_id' => $tapId, 'outcome' => $outcome]);

            return $result->setHttpResponseCode(200)->setData(['status' => 'ok', 'outcome' => $outcome]);
        } catch (\Throwable $e) {
            $this->logger->error('tap.webhook.failed', ['tap_id' => $tapId, 'error' => $e->getMessage()]);

            return $result->setHttpResponseCode(500)->setData(['status' => 'error']);
        }
    }

    // Server-to-server call without a form key: CSRF is replaced by server-side verification against the Tap API.
    public function createCsrfValidationException(RequestInterface $request): ?InvalidRequestException
    {
        return null;
    }

    public function validateForCsrf(RequestInterface $request): ?bool
    {
        return true;
    }
}
