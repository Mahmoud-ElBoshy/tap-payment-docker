<?php
declare(strict_types=1);

namespace Tap\Payment\Controller\Payment;

use Magento\Checkout\Model\Session as CheckoutSession;
use Magento\Framework\App\Action\HttpGetActionInterface;
use Magento\Framework\Controller\Result\Redirect as RedirectResult;
use Magento\Framework\Controller\Result\RedirectFactory;
use Magento\Framework\Message\ManagerInterface;
use Magento\Sales\Model\Order;
use Psr\Log\LoggerInterface;
use Tap\Payment\Model\Api\Client;
use Tap\Payment\Model\Config;
use Tap\Payment\Model\PaymentProcessor;

/**
 * Step 1: the checkout JS sends the buyer here right after "Place Order" succeeded (order exists in state "new").
 * We call Tap (/v2/charges or /v2/authorize), then redirect the buyer to transaction.url (hosted payment page).
 * If anything fails the order is canceled and the cart is restored.
 */
class Redirect implements HttpGetActionInterface
{
    public function __construct(
        private readonly CheckoutSession $checkoutSession,
        private readonly Client $client,
        private readonly PaymentProcessor $processor,
        private readonly RedirectFactory $redirectFactory,
        private readonly ManagerInterface $messageManager,
        private readonly LoggerInterface $logger
    ) {
    }

    public function execute(): RedirectResult
    {
        $order = $this->checkoutSession->getLastRealOrder();

        if (!$order->getId()
            || $order->getPayment()?->getMethod() !== Config::CODE
            || $order->getState() !== Order::STATE_NEW
        ) {
            $this->messageManager->addErrorMessage(__('We could not find a pending Tap order.'));

            return $this->redirectFactory->create()->setPath('checkout/cart');
        }

        try {
            $transaction = $this->client->createTransaction($order);
            $url = (string) $transaction['transaction']['url'];

            if (!str_starts_with($url, 'https://')) {
                throw new \RuntimeException('Tap returned a non-HTTPS payment URL.');
            }

            $order->getPayment()->setAdditionalInformation('tap_id', $transaction['id']);
            $order->addCommentToStatusHistory((string) __('Redirected to Tap. Transaction %1 awaiting payment.', $transaction['id']));
            $order->save();

            return $this->redirectFactory->create()->setUrl($url);
        } catch (\Throwable $e) {
            $this->logger->error('tap.redirect.failed', ['order' => $order->getIncrementId(), 'error' => $e->getMessage()]);

            $this->processor->cancelOrder($order, (string) __('Could not start the Tap payment: %1', $e->getMessage()));
            $this->checkoutSession->restoreQuote();
            $this->messageManager->addErrorMessage(__('We could not start the payment. Your cart has been restored, please try again.'));

            return $this->redirectFactory->create()->setPath('checkout/cart');
        }
    }
}
