<?php
declare(strict_types=1);

namespace Tap\Payment\Controller\Payment;

use Magento\Checkout\Model\Session as CheckoutSession;
use Magento\Framework\App\Action\HttpGetActionInterface;
use Magento\Framework\App\RequestInterface;
use Magento\Framework\Controller\Result\Redirect as RedirectResult;
use Magento\Framework\Controller\Result\RedirectFactory;
use Magento\Framework\Message\ManagerInterface;
use Magento\Sales\Model\OrderFactory;
use Psr\Log\LoggerInterface;
use Tap\Payment\Model\Api\Client;
use Tap\Payment\Model\PaymentProcessor;

/**
 * Step 2: Tap redirects the buyer here with ?tap_id=chg_... / auth_...
 * The query string is NOT trusted: we retrieve the transaction from Tap with the secret key and apply that.
 *
 *  success -> order Processing, transaction saved, success page
 *  failed  -> order Canceled, cart restored, redirect to cart with an error
 */
class Response implements HttpGetActionInterface
{
    public function __construct(
        private readonly RequestInterface $request,
        private readonly CheckoutSession $checkoutSession,
        private readonly Client $client,
        private readonly PaymentProcessor $processor,
        private readonly OrderFactory $orderFactory,
        private readonly RedirectFactory $redirectFactory,
        private readonly ManagerInterface $messageManager,
        private readonly LoggerInterface $logger
    ) {
    }

    public function execute(): RedirectResult
    {
        $tapId = (string) $this->request->getParam('tap_id');

        try {
            $tapData = $this->client->retrieve($tapId);
            $incrementId = (string) ($tapData['reference']['order'] ?? '');

            // The buyer must be the one who placed this order (blocks replaying someone else's tap_id).
            $sessionOrder = $this->checkoutSession->getLastRealOrder();
            if ($sessionOrder->getId() && $sessionOrder->getIncrementId() !== $incrementId) {
                throw new \RuntimeException('Tap transaction does not belong to the current checkout order.');
            }

            $result = $this->processor->process($incrementId, $tapData);
        } catch (\Throwable $e) {
            $this->logger->error('tap.response.failed', ['tap_id' => $tapId, 'error' => $e->getMessage()]);
            $this->messageManager->addErrorMessage(__('We could not verify your payment. If you were charged, please contact us.'));

            return $this->redirectFactory->create()->setPath('checkout/cart');
        }

        if ($result === PaymentProcessor::RESULT_SUCCESS) {
            $order = $this->orderFactory->create()->loadByIncrementId($incrementId);
            // Make sure the standard success page has what it needs even if the session was refreshed.
            $this->checkoutSession
                ->setLastQuoteId($order->getQuoteId())
                ->setLastSuccessQuoteId($order->getQuoteId())
                ->setLastOrderId($order->getId())
                ->setLastRealOrderId($order->getIncrementId())
                ->setLastOrderStatus($order->getStatus());

            return $this->redirectFactory->create()->setPath('checkout/onepage/success');
        }

        if ($result === PaymentProcessor::RESULT_FAILED) {
            $status = strtolower((string) ($tapData['status'] ?? 'failed'));
            $this->checkoutSession->restoreQuote();
            $this->messageManager->addErrorMessage(
                __('Your payment was %1, so the order was canceled. Your cart has been restored, please try again.', $status)
            );

            return $this->redirectFactory->create()->setPath('checkout/cart');
        }

        // Pending: Tap has not given a final answer. The webhook will finalize the order.
        $this->messageManager->addNoticeMessage(__('Your payment is still being confirmed. You will receive an email once it is complete.'));

        return $this->redirectFactory->create()->setPath('checkout/cart');
    }
}
