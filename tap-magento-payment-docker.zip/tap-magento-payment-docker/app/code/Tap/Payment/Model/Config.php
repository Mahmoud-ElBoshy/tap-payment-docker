<?php
declare(strict_types=1);

namespace Tap\Payment\Model;

use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\Encryption\EncryptorInterface;
use Magento\Store\Model\ScopeInterface;

/** Typed access to payment/tap_payment/* settings. Keys are stored encrypted and decrypted on demand. */
class Config
{
    public const CODE = 'tap_payment';
    public const MODE_CHARGE = 'charge';
    public const MODE_AUTHORIZE = 'authorize';

    public function __construct(
        private readonly ScopeConfigInterface $scopeConfig,
        private readonly EncryptorInterface $encryptor
    ) {
    }

    public function isActive(int|string|null $storeId = null): bool
    {
        return (bool) $this->get('active', $storeId);
    }

    public function getTransactionMode(int|string|null $storeId = null): string
    {
        return $this->get('transaction_mode', $storeId) === self::MODE_AUTHORIZE
            ? self::MODE_AUTHORIZE
            : self::MODE_CHARGE;
    }

    public function getSecretKey(int|string|null $storeId = null): string
    {
        return $this->decrypt((string) $this->get('test_secret_key', $storeId));
    }

    public function getPublicKey(int|string|null $storeId = null): string
    {
        return $this->decrypt((string) $this->get('test_public_key', $storeId));
    }

    public function isDebug(int|string|null $storeId = null): bool
    {
        return (bool) $this->get('debug', $storeId);
    }

    private function decrypt(string $value): string
    {
        return $value === '' ? '' : $this->encryptor->decrypt($value);
    }

    private function get(string $field, int|string|null $storeId): mixed
    {
        return $this->scopeConfig->getValue('payment/' . self::CODE . '/' . $field, ScopeInterface::SCOPE_STORE, $storeId);
    }
}
