<?php
declare(strict_types=1);

namespace Tap\Payment\Model;

/**
 * Rounds amounts to the minor-unit precision of the currency
 * (Tap's docs: KWD/BHD/OMR/JOD have 3 decimals, most others 2; JPY-like currencies 0).
 */
class AmountFormatter
{
    private const THREE_DECIMALS = ['KWD', 'BHD', 'OMR', 'JOD'];
    private const ZERO_DECIMALS = ['JPY', 'KRW', 'VND', 'CLP'];

    public function decimals(string $currency): int
    {
        $currency = strtoupper($currency);

        return match (true) {
            in_array($currency, self::THREE_DECIMALS, true) => 3,
            in_array($currency, self::ZERO_DECIMALS, true) => 0,
            default => 2,
        };
    }

    public function format(float $amount, string $currency): float
    {
        return round($amount, $this->decimals($currency));
    }

    /** Fixed-decimals string, e.g. "10.00" (AED) or "1.000" (KWD). Used to build the webhook hashstring. */
    public function toString(float $amount, string $currency): string
    {
        return number_format($amount, $this->decimals($currency), '.', '');
    }
}
