<?php
declare(strict_types=1);

namespace Tap\Payment\Model\Ui;

use Magento\Checkout\Model\ConfigProviderInterface;
use Tap\Payment\Model\Config;

class ConfigProvider implements ConfigProviderInterface
{
    public function __construct(private readonly Config $config)
    {
    }

    public function getConfig(): array
    {
        return [
            'payment' => [
                Config::CODE => [
                    'isActive' => $this->config->isActive(),
                ],
            ],
        ];
    }
}
