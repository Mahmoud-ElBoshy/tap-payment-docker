<?php
declare(strict_types=1);

namespace Tap\Payment\Model;

use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Lock\LockManagerInterface;
use Magento\Sales\Api\OrderRepositoryInterface;
use Magento\Sales\Model\Order;
use Magento\Sales\Model\OrderFactory;
use Psr\Log\LoggerInterface;

/**
 * Single place that applies a verified Tap transaction to a Magento order.
 * Called by BOTH the buyer return (Response) and the webhook, so it must be idempotent and race-safe:
 *  - a named lock serializes the two callers per order
 *  - only orders still in state "new" are touched; anything else just reports its current outcome
 */
class PaymentProcessor
{
    public const RESULT_SUCCESS = 'success';
    public const RESULT_FAILED = 'failed';
    public const RESULT_PENDING = 'pending';

    private const SUCCESS_STATUSES = ['CAPTURED', 'AUTHORIZED'];
    private const FAILURE_STATUSES = ['DECLINED', 'FAILED', 'CANCELLED', 'ABANDONED', 'TIMEDOUT', 'RESTRICTED', 'VOID', 'UNKNOWN'];

    public function __construct(
        private readonly OrderFactory $orderFactory,
        private readonly OrderRepositoryInterface $orderRepository,
        private readonly LockManagerInterface $lockManager,
        private readonly AmountFormatter $amountFormatter,
        private readonly LoggerInterface $logger
    ) {
    }

    /**
     * @param array $tapData charge/authorize object freshly retrieved from the Tap API
     * @return string one of the RESULT_* constants
     * @throws LocalizedException
     */
    public function process(string $incrementId, array $tapData): string
    {
        $status = strtoupper((string) ($tapData['status'] ?? ''));

        if ($incrementId === '' || empty($tapData['id'])) {
            throw new LocalizedException(__('Invalid Tap payload.'));
        }

        // INITIATED / in-progress (e.g. Fawry) etc.: nothing final to apply yet.
        if (!in_array($status, array_merge(self::SUCCESS_STATUSES, self::FAILURE_STATUSES), true)) {
            return self::RESULT_PENDING;
        }

        $lockName = 'tap_payment_' . $incrementId;
        if (!$this->lockManager->lock($lockName, 10)) {
            throw new LocalizedException(__('Could not lock the order for update. Please retry.'));
        }

        try {
            $order = $this->loadOrder($incrementId);

            return $this->apply($order, $tapData, $status);
        } finally {
            $this->lockManager->unlock($lockName);
        }
    }

    /** Cancels a still-unpaid order with an explanatory history comment. */
    public function cancelOrder(Order $order, string $comment): void
    {
        if (!$order->canCancel()) {
            return;
        }

        $order->addCommentToStatusHistory($comment);
        $order->cancel();
        $this->orderRepository->save($order);
    }

    private function apply(Order $order, array $tapData, string $status): string
    {
        $payment = $order->getPayment();
        if ($payment === null || $payment->getMethod() !== Config::CODE) {
            throw new LocalizedException(__('Order %1 was not paid with Tap.', $order->getIncrementId()));
        }

        // Idempotency: already handled by the other caller (return vs webhook) or by an earlier retry.
        if ($order->getState() !== Order::STATE_NEW) {
            $this->logger->info('tap.order.already_handled', ['order' => $order->getIncrementId(), 'state' => $order->getState()]);

            return $this->resultFromState($order);
        }

        $tapId = (string) $tapData['id'];
        $payment->setAdditionalInformation('tap_id', $tapId);
        $payment->setAdditionalInformation('tap_status', $status);

        if (in_array($status, self::FAILURE_STATUSES, true)) {
            $this->cancelOrder($order, (string) __('Tap payment %1 (%2). Order canceled.', strtolower($status), $tapId));
            $this->logger->info('tap.order.canceled', ['order' => $order->getIncrementId(), 'tap_id' => $tapId, 'status' => $status]);

            return self::RESULT_FAILED;
        }

        // Defense in depth: the verified amount/currency must equal the order's.
        if (!$this->amountMatches($order, $tapData)) {
            $order->addCommentToStatusHistory((string) __('Tap amount/currency mismatch for %1. Order put on hold for manual review.', $tapId));
            if ($order->canHold()) {
                $order->hold();
            }
            $this->orderRepository->save($order);
            $this->logger->error('tap.order.amount_mismatch', ['order' => $order->getIncrementId(), 'tap_id' => $tapId]);

            return self::RESULT_PENDING;
        }

        // Transaction ID (chg_... / auth_...) is attached by the notification registration below.
        $payment->setTransactionId($tapId);
        $payment->setTransactionAdditionalInfo(
            \Magento\Sales\Model\Order\Payment\Transaction::RAW_DETAILS,
            [
                'tap_id' => $tapId,
                'status' => $status,
                'amount' => (string) ($tapData['amount'] ?? ''),
                'currency' => (string) ($tapData['currency'] ?? ''),
            ]
        );

        if ($status === 'CAPTURED') {
            // Creates the invoice and a "capture" transaction.
            $payment->setIsTransactionClosed(true);
            $payment->registerCaptureNotification((float) $order->getBaseGrandTotal());
        } else {
            // AUTHORIZED: creates an "authorization" transaction (open, can be captured later).
            $payment->setIsTransactionClosed(false);
            $payment->registerAuthorizationNotification((float) $order->getBaseGrandTotal());
        }

        if ($order->getState() === Order::STATE_NEW) {
            $order->setState(Order::STATE_PROCESSING);
        }
        $order->addCommentToStatusHistory(
            (string) __('Tap payment %1 confirmed (%2).', strtolower($status), $tapId),
            $order->getConfig()->getStateDefaultStatus(Order::STATE_PROCESSING)
        );

        $this->orderRepository->save($order);
        $this->logger->info('tap.order.processing', ['order' => $order->getIncrementId(), 'tap_id' => $tapId, 'status' => $status]);

        return self::RESULT_SUCCESS;
    }

    private function amountMatches(Order $order, array $tapData): bool
    {
        $expected = $this->amountFormatter->format((float) $order->getGrandTotal(), (string) $order->getOrderCurrencyCode());

        return abs((float) ($tapData['amount'] ?? 0) - $expected) < 0.001
            && strtoupper((string) ($tapData['currency'] ?? '')) === strtoupper((string) $order->getOrderCurrencyCode());
    }

    private function resultFromState(Order $order): string
    {
        return match ($order->getState()) {
            Order::STATE_CANCELED => self::RESULT_FAILED,
            Order::STATE_PROCESSING, Order::STATE_COMPLETE => self::RESULT_SUCCESS,
            default => self::RESULT_PENDING,
        };
    }

    private function loadOrder(string $incrementId): Order
    {
        $order = $this->orderFactory->create()->loadByIncrementId($incrementId);
        if (!$order->getId()) {
            throw new LocalizedException(__('Order %1 not found.', $incrementId));
        }

        return $order;
    }
}
