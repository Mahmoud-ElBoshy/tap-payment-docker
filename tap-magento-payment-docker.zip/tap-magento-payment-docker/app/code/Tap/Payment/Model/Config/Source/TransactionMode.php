<?php
declare(strict_types=1);

namespace Tap\Payment\Model\Config\Source;

use Magento\Framework\Data\OptionSourceInterface;
use Tap\Payment\Model\Config;

class TransactionMode implements OptionSourceInterface
{
    public function toOptionArray(): array
    {
        return [
            ['value' => Config::MODE_CHARGE, 'label' => __('Charge')],
            ['value' => Config::MODE_AUTHORIZE, 'label' => __('Authorize')],
        ];
    }
}
