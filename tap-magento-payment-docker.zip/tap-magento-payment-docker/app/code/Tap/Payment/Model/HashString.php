<?php
declare(strict_types=1);

namespace Tap\Payment\Model;

/**
 * Validates the `hashstring` header Tap sends with every webhook (charge / authorize).
 *
 * Official scheme (https://developers.tap.company/docs/webhook):
 *   toBeHashed = "x_id{id}x_amount{amount}x_currency{currency}x_gateway_reference{reference.gateway}"
 *              . "x_payment_reference{reference.payment}x_status{status}x_created{transaction.created}"
 *   hashstring = HMAC-SHA256(toBeHashed, secret API key), hex
 * - amount must be rounded to the currency's decimals (AED 2.00, KWD 3.000 ...)
 * - gateway_reference is an empty string when Tap did not send one
 */
class HashString
{
    public function __construct(private readonly AmountFormatter $amountFormatter)
    {
    }

    public function validate(array $body, string $postedHash, string $secretKey): bool
    {
        if ($postedHash === '' || $secretKey === '') {
            return false;
        }

        $expected = hash_hmac('sha256', $this->canonicalString($body), $secretKey);

        return hash_equals($expected, strtolower(trim($postedHash)));
    }

    public function canonicalString(array $body): string
    {
        $currency = (string) ($body['currency'] ?? '');

        return 'x_id' . ($body['id'] ?? '')
            . 'x_amount' . $this->amountFormatter->toString((float) ($body['amount'] ?? 0), $currency)
            . 'x_currency' . $currency
            . 'x_gateway_reference' . ($body['reference']['gateway'] ?? '')
            . 'x_payment_reference' . ($body['reference']['payment'] ?? '')
            . 'x_status' . ($body['status'] ?? '')
            . 'x_created' . ($body['transaction']['created'] ?? '');
    }
}
