<?php
declare(strict_types=1);

namespace Tap\Payment\Model\Api;

use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\HTTP\Client\CurlFactory;
use Magento\Framework\UrlInterface;
use Magento\Sales\Model\Order;
use Psr\Log\LoggerInterface;
use Tap\Payment\Model\AmountFormatter;
use Tap\Payment\Model\Config;

/**
 * Thin wrapper around the Tap REST API (https://api.tap.company/v2).
 * Secret keys are only ever used in the Authorization header and never logged.
 */
class Client
{
    private const BASE_URL = 'https://api.tap.company/v2';

    public function __construct(
        private readonly Config $config,
        private readonly CurlFactory $curlFactory,
        private readonly UrlInterface $urlBuilder,
        private readonly AmountFormatter $amountFormatter,
        private readonly LoggerInterface $logger
    ) {
    }

    /**
     * Calls /v2/charges or /v2/authorize depending on the configured Transaction Mode.
     *
     * @return array{id: string, status: string, transaction: array{url: string}}
     * @throws LocalizedException
     */
    public function createTransaction(Order $order): array
    {
        $storeId = (int) $order->getStoreId();
        $isAuthorize = $this->config->getTransactionMode($storeId) === Config::MODE_AUTHORIZE;
        $billing = $order->getBillingAddress();
        $increment = (string) $order->getIncrementId();

        $payload = [
            'amount' => $this->amountFormatter->format((float) $order->getGrandTotal(), (string) $order->getOrderCurrencyCode()),
            'currency' => (string) $order->getOrderCurrencyCode(),
            'customer_initiated' => true,
            'threeDSecure' => true,
            'save_card' => false,
            'description' => 'Order #' . $increment,
            'metadata' => ['udf1' => (string) $order->getEntityId()],
            'reference' => [
                'transaction' => 'txn_' . $increment,
                'order' => $increment,
                // Tap idempotency (valid 24h): a repeated request for the same order returns the original
                // response / the same hosted-page URL instead of creating a second charge.
                'idempotent' => 'txn_' . $increment,
            ],
            'receipt' => ['email' => false, 'sms' => false],
            'customer' => [
                'first_name' => (string) ($billing?->getFirstname() ?: $order->getCustomerFirstname() ?: 'Customer'),
                'last_name' => (string) ($billing?->getLastname() ?: $order->getCustomerLastname() ?: '-'),
                'email' => (string) $order->getCustomerEmail(),
            ],
            // Charge: all payment methods enabled for the merchant. Authorize works only with credit cards,
            // so the hosted page is restricted to cards (src_card).
            'source' => ['id' => $isAuthorize ? 'src_card' : 'src_all'],
            // Request post URL: server-to-server webhook (IPN)
            'post' => ['url' => $this->urlBuilder->getUrl('tap/payment/webhook', ['_secure' => true])],
            // Request redirect URL: where the buyer lands after the hosted page
            'redirect' => ['url' => $this->urlBuilder->getUrl('tap/payment/response', ['_secure' => true])],
        ];

        // NOTE: the `auto` (auto capture/void) object is NOT sent: Tap documents it as not applicable when
        // source.id is src_all / src_card (hosted page). The authorization then lives for the card scheme's period.

        $endpoint = $isAuthorize ? '/authorize' : '/charges';
        $response = $this->request('POST', $endpoint, $payload, $storeId);

        if (empty($response['id']) || empty($response['transaction']['url'])) {
            throw new LocalizedException(__('Tap did not return a payment URL.'));
        }

        $this->logger->info('tap.transaction.created', [
            'order' => $increment,
            'endpoint' => $endpoint,
            'tap_id' => $response['id'],
            'status' => $response['status'] ?? null,
        ]);

        return $response;
    }

    /**
     * Retrieves a charge or authorization from Tap. Used to verify the real status server-side:
     * neither the redirect query string nor the webhook body is trusted.
     *
     * @throws LocalizedException
     */
    public function retrieve(string $tapId, int|string|null $storeId = null): array
    {
        // Strict whitelist: the id is interpolated into the request path.
        if (!preg_match('/^(chg|auth)_[A-Za-z0-9_-]+$/', $tapId)) {
            throw new LocalizedException(__('Invalid Tap transaction id.'));
        }

        $endpoint = str_starts_with($tapId, 'auth_') ? '/authorize/' : '/charges/';

        return $this->request('GET', $endpoint . $tapId, null, $storeId);
    }

    private function request(string $method, string $path, ?array $payload, int|string|null $storeId): array
    {
        $secret = $this->config->getSecretKey($storeId);
        if ($secret === '') {
            throw new LocalizedException(__('Tap secret key is not configured.'));
        }

        $curl = $this->curlFactory->create();
        $curl->setTimeout(30);
        $curl->addHeader('Authorization', 'Bearer ' . $secret);
        $curl->addHeader('Content-Type', 'application/json');
        $curl->addHeader('Accept', 'application/json');

        $url = self::BASE_URL . $path;

        if ($method === 'POST') {
            $curl->post($url, (string) json_encode($payload));
        } else {
            $curl->get($url);
        }

        $status = $curl->getStatus();
        $body = $curl->getBody();
        $decoded = json_decode($body, true);

        if ($this->config->isDebug($storeId)) {
            $this->logger->debug('tap.http', ['method' => $method, 'path' => $path, 'http_status' => $status]);
        }

        if ($status >= 400 || !is_array($decoded)) {
            $reason = is_array($decoded) ? ($decoded['errors'][0]['description'] ?? '') : '';
            $this->logger->error('tap.http.error', ['method' => $method, 'path' => $path, 'http_status' => $status, 'reason' => $reason]);
            throw new LocalizedException(__('Tap API error (HTTP %1).', $status));
        }

        return $decoded;
    }
}
