# Docker setup - Magento 2 Tap module

Services: `php` (PHP 8.3-FPM), `nginx`, `db` (MySQL 8.0), `opensearch` (2.12 with ICU/phonetic plugins), optional `ngrok`.
Magento lives in a named volume (`magento_src`); the module is mounted from `./app/code/Tap/Payment`
and installed as a **symlinked composer path package**, so edits to the module are live.

## Prerequisites

- Docker with Compose v2, ~6 GB RAM for the containers.
- Adobe Commerce Marketplace access keys (public/private): https://commercemarketplace.adobe.com/customer/accessKeys/
- Linux only: `sudo sysctl -w vm.max_map_count=262144` (required by OpenSearch).

## First run

```bash
make init            # creates .env (UID/GID filled in)
# edit .env: MAGENTO_PUBLIC_KEY / MAGENTO_PRIVATE_KEY
make install         # builds images, downloads + installs Magento (10-20 min), installs Tap_Payment
```

- Storefront: http://localhost:8080
- Admin: http://localhost:8080/admin, user `admin`, password from `ADMIN_PASSWORD` (2FA is disabled for dev)
- Configure: Stores > Configuration > Sales > Payment Methods > Tap Payments, then add test keys.

`make install` is idempotent; it skips the steps already done.

## Testing the full payment flow (Tap must reach your webhook)

The redirect flow works on localhost, but Tap's webhook (`/tap/payment/webhook`) needs a public HTTPS URL:

```bash
# put NGROK_AUTHTOKEN in .env first
make tunnel                                    # public URL shown at http://localhost:4040
bash bin/set-base-url.sh https://xxxx.ngrok-free.app/
```

Re-run `set-base-url.sh` whenever the ngrok URL changes (free plan). Add products via admin
(Catalog > Products) since no sample data is installed. Allowed currency is USD by default;
add KWD/SAR etc. under Stores > Configuration > General > Currency Setup if you want to test them.

## Useful commands

| Command | Purpose |
|---|---|
| `make magento cmd="cache:flush"` | run any `bin/magento` command |
| `make shell` | shell in the php container (as www-data) |
| `make tap-log` | follow `var/log/tap_payment.log` |
| `make logs` | nginx + php container logs |
| `make clean` | delete containers and ALL volumes (database, Magento files) |

After changing XML (di.xml, system.xml, layout) run `make magento cmd="cache:flush"`.
After adding new classes run `make magento cmd="setup:di:compile"` only in production mode; developer mode generates on demand.

## Troubleshooting

- **"... affected by security advisories (PKSA-...)" when installing:** Composer 2.9+ blocks packages with known advisories and the
  Magento 2.4.7 base release has some. The install script turns that blocking off (`policy.advisories.block false`) for this
  disposable local sandbox. To use a patched release instead, set `MAGENTO_VERSION` in `.env` (for example a `2.4.7-pN` patch
  release listed on Adobe's release notes) and check its PHP/OpenSearch requirements.

- **"Cannot create cache directory /var/www/.composer/cache ... Proceeding without cache":** only a warning (composer just runs
  without a cache and is slower). Fixed by `COMPOSER_HOME=/tmp/composer` in `docker-compose.yml`; apply with
  `docker compose up -d --force-recreate php`.

- **OpenSearch exits / unhealthy:** raise `vm.max_map_count` (Linux) or give Docker more memory.
- **`composer` 401 for repo.magento.com:** wrong keys in `.env`; recreate with `docker compose up -d --force-recreate php`.
- **Blank page / 404 right after install:** `docker compose restart nginx` (it needs `nginx.conf.sample` to exist).
- **Static files 404 for the Tap checkout component:** `make magento cmd="cache:flush"` and hard-refresh; in developer mode static files are generated on first request.
