# Notes: design choices, stubs, production hardening

## Choices
- **Post-auth operation: refund.** Most common merchant action; it exercises validation against the original payment
  (state, currency, cumulative amount) and needs no capture step. Void/capture only make sense for `authorization`
  payments. Consequence: refunds are accepted for `sale` payments only; refunding an authorization is rejected with
  an explicit message.
- **Authentication of incoming requests: mutual TLS**, as required by Shopify for payment/refund/confirm session
  requests. It is enforced by the web server (`docs/mtls-nginx.conf.example`) and surfaced to the app as
  `SSL_CLIENT_VERIFY`; the app also allow-lists `Shopify-Shop-Domain`. Disabled (`SHOPIFY_MTLS=off`) for simulation.
- **Outbound auth:** `X-Shopify-Access-Token`. For this exercise there is no token (stubbed driver); a real setup uses
  the OAuth token of an approved Payments Partner app (scopes `write_payment_gateways`, `write_payment_sessions`).
- **Asynchronous processing** with Laravel queues: endpoints validate, store, enqueue and answer immediately.
- **Two drivers** for the Shopify client: `fake` (stubbed responses, default) and `http` (real Payments Apps API,
  unit-tested with `Http::fake`, never run against a live store).
- **Simulator:** `php artisan shopify:simulate` plays Shopify and the buyer.

## Lifecycle guarantees
1. **Duplicate requests:** `shopify_payment_id` (Shopify's `id`, its documented idempotency key) is UNIQUE;
   `createOrFirst` is safe under concurrent duplicates. Same for refunds (`shopify_refund_id`).
2. **Single claim:** every transition is `UPDATE ... WHERE state = :from`; only one worker moves INITIATED -> PROCESSING.
3. **No double charge:** the processor decision is stored before the final mutation; retries reuse it.
4. **Finalize once:** resolve/reject runs under a cache lock and only from PROCESSING -> RESOLVED/REJECTED.
5. **Safe resends:** per Shopify's docs, mutations are idempotent per id (a repeated identical mutation returns the
   same result; only a *conflicting* mutation returns `userErrors`). So after a crash, re-sending resolve/reject/confirm
   is safe. `userErrors` are treated as non-retryable (`ShopifyUserErrorException`); network/5xx/throttling are retried
   on Shopify's documented schedule (18 retries over 24h).
6. **3DS ordering:** the app moves to CONFIRMING *before* calling `paymentSessionConfirm`, because Shopify's callback
   to the confirm session URL can arrive immediately after the mutation. The callback result is stored once and the
   payment is finished asynchronously.
7. **Self-healing:** a duplicate delivery of a session still in INITIATED re-dispatches the (idempotent) job.

## Stubbed (honest list)
- `CardDecryptor`: Shopify encrypts the card with ECIES (fingerprint, encrypted_message, ephemeral_public_key, tag).
  Here `encrypted_message` is base64 of the *decrypted* documented structure.
- `MockCardProcessor`: behaviour keyed on the card number; no real acquirer/gateway call.
- 3DS: `/3ds/{token}` is a fake issuer page; authentication data sent to Shopify is hard-coded (`transStatus` Y / N).
- All Shopify GraphQL responses (`FakeShopifyPaymentsApi`). The real client is only tested against stubbed responses.
- mTLS is documented and gated in code but not exercised end to end (needs Shopify's client certificate).
- Single shop / allow-list; no OAuth, no per-shop token storage.

## What needs Shopify Payments Partner approval (not done here, by design)
- Access to the Payments Apps API and the credit card payment extension (restricted scopes `write_payment_gateways`,
  `write_payment_sessions`; application via Shopify's payments extension review).
- Registering payment, confirm and refund session URLs on a real extension so Shopify actually sends sessions.
- Real calls to `paymentSessionResolve/Reject/Redirect/Confirm` and `refundSessionResolve/Reject` on a live store.
- Shopify's real card-encryption certificates/keys and the PCI DSS obligations of decrypting card data.
- mTLS with Shopify's client certificate and CA chain.
- App review/listing and production onboarding as a payments provider.

## Production hardening
- Real ECIES decryption inside a PCI DSS environment (HSM/KMS); never persist the PAN or the encrypted blob longer
  than needed (today it is wiped on finalization).
- OAuth install + encrypted per-shop tokens; handle `app/uninstalled`.
- Real 3DS server integration (EMVCo data forwarded to Shopify), real processor with idempotency keys, timeouts,
  circuit breaker, reconciliation reports.
- Reconciliation job for sessions stuck in PROCESSING / PENDING_3DS / CONFIRMING (timeouts, alerting).
- Pending state (`paymentSessionPending`) for asynchronous payment methods; capture/void for `authorization`.
- Rate limiting and request-size limits; Redis for locks and queues; metrics and alerts on `payment.job_failed`.
- Refund rows linked by FK; concurrent partial-refund race tests.

## Interview talking points (Shopify vs Magento)
- Shopify: asynchronous, session-based. Shopify owns the checkout; the app answers fast with a 2xx and later
  finalizes the session through GraphQL. Everything is keyed by Shopify's `id` (idempotency).
- Magento: the module sits inside checkout, creates the order, redirects to the hosted page and handles return + webhook.
- Shopify retries session requests; Magento has the return-URL vs webhook race. Both need idempotent finalization.
