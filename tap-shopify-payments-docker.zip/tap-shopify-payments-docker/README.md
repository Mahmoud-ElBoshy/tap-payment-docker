# Shopify native credit card Payments App - Laravel backend

Minimal partner payments backend for the Tap Payments case study, built against the **Payments Apps API contract**
and driven by **simulated Shopify requests** with **stubbed GraphQL responses** (live Payments Apps access needs
Shopify Payments Partner approval, which the interviewers confirmed is not expected).

Implements: payment session URL, confirm session URL, refund session URL, asynchronous processing with a mock
processor, `paymentSessionResolve` / `paymentSessionReject`, the 3DS path
(`paymentSessionRedirect` -> `paymentSessionConfirm` -> confirm callback -> resolve/reject), idempotency,
structured logs, and **one** post-auth operation: **refund**.

This repo is an overlay for a fresh Laravel 11/12 project (PHP 8.2+). With Docker, `make init` does everything
(see `DOCKER.md`).

## Setup (without Docker)

```bash
composer create-project laravel/laravel tap-shopify-payments
cd tap-shopify-payments
# copy app/, bootstrap/, config/, database/, resources/, routes/, tests/, docs/ of this repo over the project
cat .env.shopify.example   # copy the SHOPIFY_* values into .env
php artisan migrate
php artisan queue:work      # second terminal: processes sessions asynchronously
```

## Run the tests (no Shopify account needed)

```bash
php artisan test --filter="ShopifyPaymentsTest|HttpShopifyPaymentsApiTest"
```

- `ShopifyPaymentsTest` drives the endpoints like Shopify does and asserts the exact mutation order and arguments:
  approve, decline, duplicates, 3DS success (redirect -> confirm -> resolve), 3DS authentication failure,
  `confirmation_result=false`, refund, over-refund, mTLS gate.
- `HttpShopifyPaymentsApiTest` checks the real GraphQL client against stubbed Shopify responses (`Http::fake`):
  endpoint (`/payments_apps/api/{version}/graphql.json`), token header, mutations, variables, error handling.

## Simulate Shopify

```bash
php artisan shopify:simulate approve
php artisan shopify:simulate decline
php artisan shopify:simulate 3ds-success            # redirect -> buyer authenticates -> confirm -> resolve
php artisan shopify:simulate 3ds-fail               # buyer fails 3DS -> reject AUTHENTICATION_FAILED
php artisan shopify:simulate 3ds-confirm-rejected   # confirmation_result=false -> reject CONFIRMATION_REJECTED
php artisan shopify:simulate refund
php artisan shopify:simulate duplicate              # same payment id delivered 3 times: finalized once
```

The command sends payloads shaped like Shopify's request reference and prints the stubbed GraphQL calls the app made
(also in `storage/logs/payments.log`). It needs the queue worker running.

Mock card behaviour: any valid-looking number -> approved; ends with `0002` -> declined; `4000000000003220` -> 3DS challenge.

## Endpoints

| Method | Path | Purpose | Response |
|---|---|---|---|
| POST | `/shopify/payment_session` | Payment session URL | 200, empty body |
| POST | `/shopify/confirm_session` | Confirm session URL (3DS) | 200 |
| POST | `/shopify/refund_session` | Refund session URL | 201, empty body |
| GET/POST | `/3ds/{token}` | Mock 3DS challenge page (shown in Shopify's iframe) | HTML |

Requests are authenticated with **mutual TLS** (terminated at the web server, see `docs/mtls-nginx.conf.example`);
`SHOPIFY_MTLS=off` is used for simulation.

## Layout

- `app/Services/PaymentLifecycle.php` - state machine (INITIATED, PROCESSING, PENDING_3DS, CONFIRMING, RESOLVED, REJECTED)
- `app/Services/RefundLifecycle.php` - refund state machine
- `app/Services/Shopify/*` - GraphQL client (`http`) and stubbed responses (`fake`) behind one interface
- `app/Services/Processor/*` - stubbed card decryptor and mock processor
- `docs/SEQUENCE_DIAGRAMS.md` - non-3DS, 3DS and refund flows
- `docs/NOTES.md` - choices, stubs, what needs Partner approval, production hardening
- `docs/CONTRACT_CHECK.md` - what was verified against Shopify's docs and what was corrected
