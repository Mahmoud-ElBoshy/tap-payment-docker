<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Mock 3-D Secure</title>
    <style>
        body { font-family: system-ui, sans-serif; background: #f4f4f5; display: grid; place-items: center; min-height: 100vh; margin: 0; }
        .card { background: #fff; padding: 2rem; border-radius: 12px; max-width: 380px; box-shadow: 0 4px 20px rgba(0,0,0,.08); }
        button { padding: .7rem 1.2rem; border: 0; border-radius: 8px; cursor: pointer; font-size: 1rem; margin-right: .5rem; }
        .ok { background: #16a34a; color: #fff; } .ko { background: #dc2626; color: #fff; }
    </style>
</head>
<body>
<div class="card">
    <h2>Mock 3-D Secure</h2>
    <p>Authenticate payment of <strong>{{ $session->amount }} {{ $session->currency }}</strong> (demo issuer page).</p>
    @if ($pending)
        <form method="POST" action="{{ route('3ds.confirm', $session->three_ds_token) }}">
            @csrf
            <button class="ok" name="result" value="success">Authenticate</button>
            <button class="ko" name="result" value="failure">Fail</button>
        </form>
    @else
        <p>This authentication has already been completed.</p>
    @endif
</div>
</body>
</html>
