<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Mock 3-D Secure</title>
    @if ($url)
        <script>
            // Shopify shows this page in an iframe: navigate the PARENT browsing context back to Shopify.
            (function () {
                var target = @json($url);
                try { window.parent.location.href = target; } catch (e) { window.location.href = target; }
            })();
        </script>
    @endif
</head>
<body style="font-family: system-ui, sans-serif; text-align: center; padding: 2rem;">
@if ($url)
    <p>Redirecting&hellip; <a href="{{ $url }}" target="_top">Continue</a></p>
@else
    <p>Your payment is being processed. You can close this window.</p>
@endif
</body>
</html>
