<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('payment_sessions', function (Blueprint $t) {
            $t->id();
            // Shopify's payment id. The UNIQUE index is the idempotency guard against duplicate requests.
            $t->string('shopify_payment_id')->unique();
            $t->string('shopify_gid');
            $t->string('shop_domain');
            $t->string('kind')->default('sale'); // sale | authorization
            $t->decimal('amount', 12, 2);
            $t->string('currency', 3);
            $t->boolean('test')->default(true);

            // INITIATED, PROCESSING, PENDING_3DS, CONFIRMING, RESOLVED, REJECTED
            $t->string('state')->index();
            // Persisted BEFORE calling Shopify so a retry never re-charges the card.
            $t->string('decision')->nullable(); // approved | declined
            $t->string('decline_code')->nullable();
            $t->string('decline_message')->nullable();
            $t->string('processor_reference')->nullable();

            $t->string('three_ds_token')->nullable()->unique();
            $t->timestamp('redirect_sent_at')->nullable();
            $t->text('buyer_redirect_url')->nullable();

            // 3DS: authentication data we pass to resolve/reject (required once paymentSessionRedirect was used)
            $t->json('three_ds_data')->nullable();
            // 3DS: result of Shopify's POST to the confirm session URL (null = not received yet)
            $t->boolean('confirmation_result')->nullable();
            // URL returned by paymentSessionConfirm (where the buyer is sent back to Shopify)
            $t->text('confirm_redirect_url')->nullable();

            // Encrypted blob received from Shopify. Cleared once the session is finalized.
            $t->text('encrypted_card')->nullable();
            // Request body WITHOUT payment_method.data (no card material in the stored payload).
            $t->json('payload');

            $t->timestamp('finalized_at')->nullable();
            $t->timestamps();
        });

        Schema::create('refund_sessions', function (Blueprint $t) {
            $t->id();
            $t->string('shopify_refund_id')->unique();
            $t->string('shopify_gid');
            $t->string('shop_domain');
            $t->string('payment_ref'); // Shopify payment id being refunded
            $t->decimal('amount', 12, 2);
            $t->string('currency', 3);
            $t->boolean('test')->default(true);

            // INITIATED, PROCESSING, RESOLVED, REJECTED
            $t->string('state')->index();
            $t->string('decision')->nullable();
            $t->string('decline_code')->nullable();
            $t->string('decline_message')->nullable();
            $t->string('processor_reference')->nullable();
            $t->json('payload');
            $t->timestamp('finalized_at')->nullable();
            $t->timestamps();

            $t->index('payment_ref');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('refund_sessions');
        Schema::dropIfExists('payment_sessions');
    }
};
