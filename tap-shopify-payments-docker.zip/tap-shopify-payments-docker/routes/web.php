<?php

use App\Http\Controllers\ConfirmSessionController;
use App\Http\Controllers\PaymentSessionController;
use App\Http\Controllers\RefundSessionController;
use App\Http\Controllers\ThreeDsController;
use App\Http\Middleware\VerifyShopifyRequest;
use Illuminate\Support\Facades\Route;

// Endpoints called by Shopify (URLs configured in the credit card payments app extension).
Route::middleware(VerifyShopifyRequest::class)->prefix('shopify')->group(function () {
    Route::post('payment_session', [PaymentSessionController::class, 'store']);
    Route::post('confirm_session', [ConfirmSessionController::class, 'store']);
    Route::post('refund_session', [RefundSessionController::class, 'store']);
});

// Mock 3DS challenge page (stands in for the issuer ACS). Shopify renders it inside an iframe.
Route::get('3ds/{token}', [ThreeDsController::class, 'show'])->name('3ds.show');
Route::post('3ds/{token}', [ThreeDsController::class, 'confirm'])->name('3ds.confirm');
