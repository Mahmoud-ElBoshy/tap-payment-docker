<?php

use Illuminate\Foundation\Application;
use Illuminate\Foundation\Configuration\Exceptions;
use Illuminate\Foundation\Configuration\Middleware;

return Application::configure(basePath: dirname(__DIR__))
    ->withRouting(
        web: __DIR__.'/../routes/web.php',
        commands: __DIR__.'/../routes/console.php',
        health: '/up',
    )
    ->withMiddleware(function (Middleware $middleware): void {
        // Shopify calls these endpoints server-to-server; they are authenticated with mTLS (see VerifyShopifyRequest) instead of CSRF.
        $middleware->validateCsrfTokens(except: ['shopify/*']);
    })
    ->withExceptions(function (Exceptions $exceptions): void {
        //
    })->create();
