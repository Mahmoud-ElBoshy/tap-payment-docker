<?php

namespace Tests\Feature;

use App\Exceptions\ShopifyApiException;
use App\Exceptions\ShopifyUserErrorException;
use App\Models\PaymentSession;
use App\Services\Shopify\HttpShopifyPaymentsApi;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Http\Client\Request;
use Illuminate\Support\Facades\Http;
use Tests\TestCase;

/**
 * Verifies the real GraphQL client against STUBBED Shopify responses (Http::fake):
 * Payments Apps API endpoint, auth header, mutation names, variables and error handling.
 */
class HttpShopifyPaymentsApiTest extends TestCase
{
    use RefreshDatabase;

    private const ENDPOINT = 'https://dev.myshopify.com/payments_apps/api/2026-10/graphql.json';

    protected function setUp(): void
    {
        parent::setUp();
        config(['shopify.access_token' => 'shpat_test', 'shopify.api_version' => '2026-10']);
    }

    public function test_resolve_uses_the_payments_apps_endpoint_and_sends_3ds_authentication(): void
    {
        Http::fake(['*' => Http::response(['data' => ['paymentSessionResolve' => [
            'paymentSession' => ['id' => 'gid://shopify/PaymentSession/1', 'state' => ['code' => 'RESOLVED']],
            'userErrors' => [],
        ]]])]);

        $auth = ['authenticationData' => ['authenticationFlow' => 'CHALLENGE', 'transStatus' => 'Y']];
        (new HttpShopifyPaymentsApi())->resolvePayment($this->makePaymentSession(), null, $auth);

        Http::assertSent(function (Request $r) {
            return $r->url() === self::ENDPOINT
                && $r->hasHeader('X-Shopify-Access-Token', 'shpat_test')
                && str_contains($r['query'], 'paymentSessionResolve')
                && $r['variables']['id'] === 'gid://shopify/PaymentSession/1'
                && $r['variables']['authentication']['authenticationData']['transStatus'] === 'Y';
        });
    }

    public function test_reject_sends_reason_code_and_message(): void
    {
        Http::fake(['*' => Http::response(['data' => ['paymentSessionReject' => [
            'paymentSession' => ['id' => 'x'], 'userErrors' => [],
        ]]])]);

        (new HttpShopifyPaymentsApi())->rejectPayment($this->makePaymentSession(), 'CARD_DECLINED', 'Declined');

        Http::assertSent(fn (Request $r) => str_contains($r['query'], 'paymentSessionReject')
            && $r['variables']['reason'] === ['code' => 'CARD_DECLINED', 'merchantMessage' => 'Declined']);
    }

    public function test_redirect_sends_the_3ds_url(): void
    {
        Http::fake(['*' => Http::response(['data' => ['paymentSessionRedirect' => [
            'paymentSession' => ['id' => 'x'], 'userErrors' => [],
        ]]])]);

        (new HttpShopifyPaymentsApi())->redirectPayment($this->makePaymentSession(), 'https://app.example/3ds/abc');

        Http::assertSent(fn (Request $r) => str_contains($r['query'], 'paymentSessionRedirect')
            && $r['variables']['redirectUrl'] === 'https://app.example/3ds/abc');
    }

    public function test_redirect_requires_an_https_url(): void
    {
        Http::fake();

        $this->expectException(ShopifyApiException::class);

        (new HttpShopifyPaymentsApi())->redirectPayment($this->makePaymentSession(), 'http://localhost/3ds/abc');
    }

    public function test_confirm_returns_the_url_to_send_the_buyer_back_to_shopify(): void
    {
        Http::fake(['*' => Http::response(['data' => ['paymentSessionConfirm' => [
            'paymentSession' => ['id' => 'x', 'nextAction' => [
                'action' => 'REDIRECT',
                'context' => ['redirectUrl' => 'https://shop.example/checkout/continue'],
            ]],
            'userErrors' => [],
        ]]])]);

        $url = (new HttpShopifyPaymentsApi())->confirmPayment($this->makePaymentSession());

        $this->assertSame('https://shop.example/checkout/continue', $url);
        Http::assertSent(fn (Request $r) => str_contains($r['query'], 'paymentSessionConfirm'));
    }

    public function test_refund_mutations(): void
    {
        Http::fake(['*' => Http::response(['data' => [
            'refundSessionResolve' => ['refundSession' => ['id' => 'x'], 'userErrors' => []],
        ]])]);

        $refund = new \App\Models\RefundSession(['shopify_gid' => 'gid://shopify/RefundSession/9', 'shop_domain' => 'dev.myshopify.com']);
        (new HttpShopifyPaymentsApi())->resolveRefund($refund);

        Http::assertSent(fn (Request $r) => $r->url() === self::ENDPOINT
            && str_contains($r['query'], 'refundSessionResolve')
            && $r['variables']['id'] === 'gid://shopify/RefundSession/9');
    }

    public function test_user_errors_raise_a_non_retryable_exception(): void
    {
        Http::fake(['*' => Http::response(['data' => ['paymentSessionResolve' => [
            'paymentSession' => null,
            'userErrors' => [['field' => ['id'], 'message' => 'Session already rejected']],
        ]]])]);

        $this->expectException(ShopifyUserErrorException::class);

        (new HttpShopifyPaymentsApi())->resolvePayment($this->makePaymentSession());
    }

    public function test_graphql_errors_and_http_failures_are_retryable_exceptions(): void
    {
        Http::fakeSequence()
            ->push(['errors' => [['message' => 'Throttled', 'extensions' => ['code' => 'THROTTLED']]]], 200)
            ->push('boom', 500);

        $api = new HttpShopifyPaymentsApi();
        $session = $this->makePaymentSession();

        foreach ([1, 2] as $_) {
            try {
                $api->resolvePayment($session);
                $this->fail('Expected ShopifyApiException');
            } catch (ShopifyUserErrorException) {
                $this->fail('Throttling must not be a user error');
            } catch (ShopifyApiException) {
                $this->assertTrue(true);
            }
        }
    }

    private function makePaymentSession(): PaymentSession
    {
        return PaymentSession::create([
            'shopify_payment_id' => '1',
            'shopify_gid' => 'gid://shopify/PaymentSession/1',
            'shop_domain' => 'dev.myshopify.com',
            'kind' => 'sale',
            'amount' => '10.00',
            'currency' => 'USD',
            'state' => 'PROCESSING',
            'payload' => [],
        ]);
    }
}
