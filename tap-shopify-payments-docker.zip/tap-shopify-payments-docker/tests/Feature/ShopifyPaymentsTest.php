<?php

namespace Tests\Feature;

use App\Enums\PaymentSessionState;
use App\Enums\RefundSessionState;
use App\Models\PaymentSession;
use App\Models\RefundSession;
use App\Services\Shopify\FakeShopifyPaymentsApi;
use App\Services\Shopify\ShopifyPaymentsApi;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Testing\TestResponse;
use Tests\TestCase;

class ShopifyPaymentsTest extends TestCase
{
    use RefreshDatabase;

    private FakeShopifyPaymentsApi $shopify;

    protected function setUp(): void
    {
        parent::setUp();

        config([
            'queue.default' => 'sync', // jobs run inline so the whole flow is testable
            'shopify.mtls' => 'off',
            'shopify.shop_domain' => 'dev.myshopify.com',
        ]);

        $this->shopify = new FakeShopifyPaymentsApi();
        $this->app->instance(ShopifyPaymentsApi::class, $this->shopify);
    }

    // ---- authentication (mTLS terminated at the web server) -----------------------------------

    public function test_mtls_proxy_mode_rejects_requests_without_a_verified_client_certificate(): void
    {
        config(['shopify.mtls' => 'proxy']);

        $this->postPayment('m1', '4242424242424242')->assertStatus(401);
        $this->assertSame(0, PaymentSession::count());

        $this->postPayment('m2', '4242424242424242', server: ['SSL_CLIENT_VERIFY' => 'SUCCESS'])->assertStatus(200);
        $this->assertSame(1, PaymentSession::count());
    }

    public function test_unknown_shop_is_rejected(): void
    {
        $this->postPayment('s1', '4242424242424242', server: ['HTTP_SHOPIFY_SHOP_DOMAIN' => 'other.myshopify.com'])->assertStatus(403);
    }

    public function test_payload_must_follow_the_request_reference(): void
    {
        $this->shopifyPost('/shopify/payment_session', ['id' => 'bad'])->assertStatus(422);
    }

    // ---- payments without 3DS ---------------------------------------------------------------

    public function test_non_3ds_payment_is_resolved_once_without_authentication_data(): void
    {
        $this->postPayment('p1', '4242424242424242')->assertStatus(200);

        $session = PaymentSession::firstOrFail();
        $this->assertSame(PaymentSessionState::Resolved, $session->state);
        $this->assertSame(['resolvePayment'], $this->shopify->callNames());
        $this->assertNull($this->shopify->calls[0][1]['authentication']);
        $this->assertNull($session->getRawOriginal('encrypted_card'), 'card blob is wiped after finalization');
    }

    public function test_declined_card_is_rejected(): void
    {
        $this->postPayment('p2', '4000000000000002');

        $this->assertSame(PaymentSessionState::Rejected, PaymentSession::firstOrFail()->state);
        $this->assertSame(['rejectPayment'], $this->shopify->callNames());
        $this->assertSame('CARD_DECLINED', $this->shopify->calls[0][1]['code']);
    }

    public function test_duplicate_requests_do_not_double_finalize(): void
    {
        $this->postPayment('p3', '4242424242424242');
        $this->postPayment('p3', '4242424242424242');
        $this->postPayment('p3', '4242424242424242');

        $this->assertSame(1, PaymentSession::count());
        $this->assertSame(['resolvePayment'], $this->shopify->callNames());
    }

    // ---- 3DS: redirect -> confirm -> resolve/reject -----------------------------------------

    public function test_3ds_success_flow_redirect_confirm_resolve(): void
    {
        $this->postPayment('p4', '4000000000003220');

        $session = PaymentSession::firstOrFail();
        $this->assertSame(PaymentSessionState::Pending3ds, $session->state);
        $this->assertSame(['redirectPayment'], $this->shopify->callNames());

        // Buyer authenticates inside Shopify's iframe -> app calls paymentSessionConfirm, buyer goes back to Shopify.
        $this->post(route('3ds.confirm', $session->three_ds_token), ['result' => 'success'])
            ->assertOk()
            ->assertSee('fake-confirm-return/p4');
        $this->assertSame(PaymentSessionState::Confirming, $session->refresh()->state);
        $this->assertSame(['redirectPayment', 'confirmPayment'], $this->shopify->callNames());

        // Shopify delivers the confirmation result to the confirm session URL -> app resolves.
        $this->postConfirm('p4', true)->assertStatus(200);
        $this->assertSame(PaymentSessionState::Resolved, $session->refresh()->state);
        $this->assertSame(['redirectPayment', 'confirmPayment', 'resolvePayment'], $this->shopify->callNames());

        // resolve must carry the 3DS authentication data (required after paymentSessionRedirect)
        $auth = $this->shopify->calls[2][1]['authentication']['authenticationData'];
        $this->assertSame('Y', $auth['transStatus']);

        // duplicates: confirm callback redelivered + double click on the 3DS button
        $this->postConfirm('p4', true)->assertStatus(200);
        $this->post(route('3ds.confirm', $session->three_ds_token), ['result' => 'success'])->assertOk();
        $this->assertSame(['redirectPayment', 'confirmPayment', 'resolvePayment'], $this->shopify->callNames());
    }

    public function test_3ds_authentication_failure_rejects_without_confirm(): void
    {
        $this->postPayment('p5', '4000000000003220');
        $session = PaymentSession::firstOrFail();

        $this->post(route('3ds.confirm', $session->three_ds_token), ['result' => 'failure'])->assertOk();

        $this->assertSame(PaymentSessionState::Rejected, $session->refresh()->state);
        $this->assertSame(['redirectPayment', 'rejectPayment'], $this->shopify->callNames());
        $this->assertSame('AUTHENTICATION_FAILED', $this->shopify->calls[1][1]['code']);
        $this->assertSame('N', $this->shopify->calls[1][1]['authentication']['authenticationData']['transStatus']);
    }

    public function test_confirmation_result_false_is_rejected_with_confirmation_rejected(): void
    {
        $this->postPayment('p6', '4000000000003220');
        $session = PaymentSession::firstOrFail();
        $this->post(route('3ds.confirm', $session->three_ds_token), ['result' => 'success'])->assertOk();

        $this->postConfirm('p6', false)->assertStatus(200);

        $this->assertSame(PaymentSessionState::Rejected, $session->refresh()->state);
        $this->assertSame(['redirectPayment', 'confirmPayment', 'rejectPayment'], $this->shopify->callNames());
        $this->assertSame('CONFIRMATION_REJECTED', $this->shopify->calls[2][1]['code']);
        $this->assertNotContains('resolvePayment', $this->shopify->callNames());
    }

    public function test_confirm_for_unknown_session_is_404(): void
    {
        $this->postConfirm('nope', true)->assertStatus(404);
    }

    // ---- refund (post-authorization operation) ----------------------------------------------

    public function test_refund_is_resolved_then_over_refund_is_rejected(): void
    {
        $this->postPayment('p7', '4242424242424242', amount: '10.00');

        $this->postRefund('r1', 'p7', '4.00')->assertStatus(201); // documented: HTTP 201, empty body
        $this->assertSame(RefundSessionState::Resolved, RefundSession::where('shopify_refund_id', 'r1')->firstOrFail()->state);

        $this->postRefund('r2', 'p7', '7.00'); // 4 + 7 > 10
        $this->assertSame(RefundSessionState::Rejected, RefundSession::where('shopify_refund_id', 'r2')->firstOrFail()->state);

        // duplicate delivery of r1 must not refund again
        $this->postRefund('r1', 'p7', '4.00');

        $this->assertSame(['resolvePayment', 'resolveRefund', 'rejectRefund'], $this->shopify->callNames());
    }

    // ---- helpers ----------------------------------------------------------------------------

    private function postPayment(string $id, string $pan, string $amount = '10.00', string $kind = 'sale', array $server = []): TestResponse
    {
        $card = ['type' => 'card', 'data' => [
            'full_name' => 'Test Buyer', 'pan' => $pan, 'month' => 12, 'year' => 2099, 'verification_value' => '123',
        ]];

        return $this->shopifyPost('/shopify/payment_session', [
            'id' => $id,
            'gid' => "gid://shopify/PaymentSession/{$id}",
            'group' => 'grp',
            'session_id' => 'sess',
            'amount' => $amount,
            'currency' => 'USD',
            'test' => true,
            'merchant_locale' => 'en',
            'proposed_at' => '2026-10-13T00:00:00Z',
            'kind' => $kind,
            'payment_method' => ['type' => 'credit_card', 'data' => [
                'fingerprint' => 'fp',
                'encrypted_message' => base64_encode(json_encode($card)),
                'ephemeral_public_key' => 'epk',
                'tag' => 'tag',
                'moto' => false,
            ]],
            'customer' => ['email' => 'buyer@example.com', 'locale' => 'en'],
            'client_details' => ['ip_address' => '127.0.0.1', 'user_agent' => 'phpunit'],
        ], $server);
    }

    private function postConfirm(string $id, bool $result): TestResponse
    {
        return $this->shopifyPost('/shopify/confirm_session', [
            'id' => $id,
            'gid' => "gid://shopify/PaymentSession/{$id}",
            'confirmation_result' => $result,
        ]);
    }

    private function postRefund(string $id, string $paymentId, string $amount): TestResponse
    {
        return $this->shopifyPost('/shopify/refund_session', [
            'id' => $id,
            'gid' => "gid://shopify/RefundSession/{$id}",
            'payment_id' => $paymentId,
            'amount' => $amount,
            'currency' => 'USD',
            'test' => true,
            'merchant_locale' => 'en',
            'proposed_at' => '2026-10-13T00:00:00Z',
        ]);
    }

    /** Sends a request with the headers Shopify sends. */
    private function shopifyPost(string $uri, array $payload, array $server = []): TestResponse
    {
        return $this->call('POST', $uri, [], [], [], $server + [
            'CONTENT_TYPE' => 'application/json',
            'HTTP_ACCEPT' => 'application/json',
            'HTTP_SHOPIFY_SHOP_DOMAIN' => 'dev.myshopify.com',
            'HTTP_SHOPIFY_REQUEST_ID' => 'req-'.uniqid(),
            'HTTP_SHOPIFY_API_VERSION' => '2026-10',
        ], json_encode($payload));
    }
}
