<?php

namespace App\Models;

use App\Enums\Outcome;
use App\Enums\PaymentSessionState;
use Illuminate\Database\Eloquent\Model;

class PaymentSession extends Model
{
    protected $guarded = [];

    protected $hidden = ['encrypted_card'];

    protected function casts(): array
    {
        return [
            'state' => PaymentSessionState::class,
            'decision' => Outcome::class,
            'test' => 'boolean',
            'payload' => 'array',
            'three_ds_data' => 'array',
            'confirmation_result' => 'boolean',
            'encrypted_card' => 'encrypted',
            'redirect_sent_at' => 'datetime',
            'finalized_at' => 'datetime',
        ];
    }
}
