<?php

namespace App\Models;

use App\Enums\Outcome;
use App\Enums\RefundSessionState;
use Illuminate\Database\Eloquent\Model;

class RefundSession extends Model
{
    protected $guarded = [];

    protected function casts(): array
    {
        return [
            'state' => RefundSessionState::class,
            'decision' => Outcome::class,
            'test' => 'boolean',
            'payload' => 'array',
            'finalized_at' => 'datetime',
        ];
    }
}
