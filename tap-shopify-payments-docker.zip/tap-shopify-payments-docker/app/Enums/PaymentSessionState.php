<?php

namespace App\Enums;

enum PaymentSessionState: string
{
    case Initiated = 'INITIATED';
    case Processing = 'PROCESSING';
    case Pending3ds = 'PENDING_3DS';
    case Confirming = 'CONFIRMING';
    case Resolved = 'RESOLVED';
    case Rejected = 'REJECTED';

    public function isFinal(): bool
    {
        return $this === self::Resolved || $this === self::Rejected;
    }
}
