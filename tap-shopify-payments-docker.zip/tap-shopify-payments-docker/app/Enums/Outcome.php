<?php

namespace App\Enums;

/** Result of talking to the (mock) card processor. Only Approved/Declined are ever stored as a decision. */
enum Outcome: string
{
    case Approved = 'approved';
    case Declined = 'declined';
    case Challenge = 'challenge'; // 3DS required
}
