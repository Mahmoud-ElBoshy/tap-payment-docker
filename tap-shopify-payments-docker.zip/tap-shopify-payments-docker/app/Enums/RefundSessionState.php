<?php

namespace App\Enums;

enum RefundSessionState: string
{
    case Initiated = 'INITIATED';
    case Processing = 'PROCESSING';
    case Resolved = 'RESOLVED';
    case Rejected = 'REJECTED';

    public function isFinal(): bool
    {
        return $this === self::Resolved || $this === self::Rejected;
    }
}
