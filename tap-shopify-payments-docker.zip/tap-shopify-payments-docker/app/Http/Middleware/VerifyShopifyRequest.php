<?php

namespace App\Http\Middleware;

use App\Support\PaymentLog;
use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

/**
 * Authenticates requests coming from Shopify.
 *
 * Per Shopify's "Implementation considerations", payments apps must use mutual TLS: Shopify presents its own client
 * certificate and the app validates it against Shopify's CA. That check happens in the web server (see
 * docs/mtls-nginx.conf.example), which tells PHP the result through the SSL_CLIENT_VERIFY server variable.
 * This middleware trusts that variable (it cannot be spoofed by a client: it is not an HTTP header) and also
 * allow-lists the shop sent in the Shopify-Shop-Domain header.
 *
 * SHOPIFY_MTLS=off disables the certificate check for simulation/local development only.
 */
class VerifyShopifyRequest
{
    public function handle(Request $request, Closure $next): Response
    {
        if (config('shopify.mtls') === 'proxy' && $request->server('SSL_CLIENT_VERIFY') !== 'SUCCESS') {
            PaymentLog::warning('shopify.mtls.rejected', ['path' => $request->path()]);
            abort(401, 'Client certificate not verified.');
        }

        $allowedShop = config('shopify.shop_domain');
        $shop = (string) $request->header('Shopify-Shop-Domain', '');

        if ($allowedShop && $shop !== $allowedShop) {
            PaymentLog::warning('shopify.shop.unknown', ['shop' => $shop]);
            abort(403, 'Unknown shop.');
        }

        return $next($request);
    }
}
