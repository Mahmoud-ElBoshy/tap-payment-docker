<?php

namespace App\Http\Controllers;

use App\Enums\PaymentSessionState;
use App\Models\PaymentSession;
use App\Services\PaymentLifecycle;
use Illuminate\Http\Request;
use Illuminate\Contracts\View\View;

/**
 * MOCK issuer challenge page. Shopify sends the buyer here after our paymentSessionRedirect.
 * In production this would be the issuer's ACS and we would receive its result (e.g. via a processor callback).
 */
class ThreeDsController extends Controller
{
    public function show(string $token): View
    {
        $session = PaymentSession::where('three_ds_token', $token)->firstOrFail();

        return view('threeds', [
            'session' => $session,
            'pending' => $session->state === PaymentSessionState::Pending3ds,
        ]);
    }

    public function confirm(Request $request, string $token, PaymentLifecycle $lifecycle): View
    {
        $data = $request->validate(['result' => ['required', 'in:success,failure']]);

        $url = $lifecycle->complete3ds($token, $data['result'] === 'success');

        // Shopify renders this page in an iframe; the buyer must be sent back to Shopify through the PARENT window.
        return view('threeds-redirect', ['url' => $url]);
    }
}
