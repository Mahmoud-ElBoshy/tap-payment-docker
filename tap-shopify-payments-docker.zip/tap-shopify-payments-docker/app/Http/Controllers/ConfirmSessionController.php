<?php

namespace App\Http\Controllers;

use App\Jobs\ProcessPaymentSession;
use App\Models\PaymentSession;
use App\Support\PaymentLog;
use Illuminate\Http\Request;
use Illuminate\Http\Response;

/**
 * Confirm Session URL. After the app calls paymentSessionConfirm, Shopify POSTs the confirmation result here:
 * {"id": "...", "gid": "...", "confirmation_result": true|false}.
 * We record it (once) and finish the payment asynchronously; the response is a fast 200.
 */
class ConfirmSessionController extends Controller
{
    public function store(Request $request): Response
    {
        $data = $request->validate([
            'id' => ['required', 'string'],
            'gid' => ['required', 'string'],
            'confirmation_result' => ['required', 'boolean'],
        ]);

        $session = PaymentSession::where('shopify_payment_id', $data['id'])->first();

        if (! $session) {
            PaymentLog::warning('payment.confirm.unknown_session', ['payment_id' => $data['id']]);

            return response()->noContent(404);
        }

        // Idempotent: only the first delivery stores the result.
        PaymentSession::whereKey($session->id)->whereNull('confirmation_result')
            ->update(['confirmation_result' => (bool) $data['confirmation_result']]);

        PaymentLog::info('payment.confirm.received', [
            'payment_id' => $session->shopify_payment_id,
            'confirmation_result' => (bool) $data['confirmation_result'],
            'request_id' => $request->header('Shopify-Request-Id'),
        ]);

        ProcessPaymentSession::dispatch($session->id);

        return response()->noContent(200);
    }
}
