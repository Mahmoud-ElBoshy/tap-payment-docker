<?php

namespace App\Http\Controllers;

use App\Enums\RefundSessionState;
use App\Jobs\ProcessRefundSession;
use App\Models\RefundSession;
use App\Support\PaymentLog;
use Illuminate\Http\Request;
use Illuminate\Http\Response;

/** Refund Session URL. Same pattern as the payment session endpoint: persist, queue, answer fast (HTTP 201). */
class RefundSessionController extends Controller
{
    public function store(Request $request): Response
    {
        $data = $request->validate([
            'id' => ['required', 'string'],
            'gid' => ['required', 'string'],
            'payment_id' => ['required', 'string'],
            'amount' => ['required', 'numeric', 'gt:0'],
            'currency' => ['required', 'string', 'size:3'],
            'test' => ['required', 'boolean'],
            'merchant_locale' => ['required', 'string'],
            'proposed_at' => ['required', 'string'],
        ]);

        $refund = RefundSession::createOrFirst(
            ['shopify_refund_id' => $data['id']],
            [
                'shopify_gid' => $data['gid'],
                'shop_domain' => (string) $request->header('Shopify-Shop-Domain', config('shopify.shop_domain')),
                'payment_ref' => $data['payment_id'],
                'amount' => $data['amount'],
                'currency' => strtoupper($data['currency']),
                'test' => (bool) $data['test'],
                'state' => RefundSessionState::Initiated->value,
                'payload' => $request->all(),
            ]
        );

        if ($refund->wasRecentlyCreated || $refund->state === RefundSessionState::Initiated) {
            PaymentLog::info($refund->wasRecentlyCreated ? 'refund.session.received' : 'refund.session.redispatched', [
                'refund_id' => $refund->shopify_refund_id,
                'payment_id' => $refund->payment_ref,
            ]);
            ProcessRefundSession::dispatch($refund->id);
        } else {
            PaymentLog::info('refund.session.duplicate', ['refund_id' => $refund->shopify_refund_id, 'state' => $refund->state->value]);
        }

        // Documented: Shopify must receive HTTP 201 (Created) with an empty body.
        return response()->noContent(201);
    }
}
