<?php

namespace App\Http\Controllers;

use App\Enums\PaymentSessionState;
use App\Jobs\ProcessPaymentSession;
use App\Models\PaymentSession;
use App\Support\PaymentLog;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Arr;

/**
 * Payment Session URL (credit card extension). Shopify POSTs here when a buyer pays with a card.
 * Per the request reference: headers Shopify-Shop-Domain / Shopify-Request-Id / Shopify-Api-Version, the payment
 * `id` is the idempotency key, and the response is any 2xx with an empty body.
 * We persist the session, queue the real work and answer immediately.
 */
class PaymentSessionController extends Controller
{
    public function store(Request $request): Response
    {
        $data = $request->validate([
            'id' => ['required', 'string'],
            'gid' => ['required', 'string'],
            'group' => ['required', 'string'],
            'session_id' => ['nullable', 'string'],            // 2024-10+
            'amount' => ['required', 'numeric', 'gt:0'],
            'currency' => ['required', 'string', 'size:3'],
            'test' => ['required', 'boolean'],
            'merchant_locale' => ['required', 'string'],
            'proposed_at' => ['required', 'string'],
            'kind' => ['required', 'in:sale,authorization'],
            'payment_method.type' => ['required', 'in:credit_card'],
            'payment_method.data.fingerprint' => ['required', 'string'],
            'payment_method.data.encrypted_message' => ['required', 'string'],
            'payment_method.data.ephemeral_public_key' => ['required', 'string'],
            'payment_method.data.tag' => ['required', 'string'],
            'client_details.ip_address' => ['nullable', 'string'], // present when 3DS is supported
        ]);

        // Idempotency: shopify_payment_id is UNIQUE. createOrFirst is safe under concurrent duplicates.
        $session = PaymentSession::createOrFirst(
            ['shopify_payment_id' => $data['id']],
            [
                'shopify_gid' => $data['gid'],
                'shop_domain' => (string) $request->header('Shopify-Shop-Domain', config('shopify.shop_domain')),
                'kind' => $data['kind'],
                'amount' => $data['amount'],
                'currency' => strtoupper($data['currency']),
                'test' => (bool) $data['test'],
                'state' => PaymentSessionState::Initiated->value,
                'encrypted_card' => $request->input('payment_method.data.encrypted_message'),
                // Never keep payment_method.data in the stored payload.
                'payload' => Arr::except($request->all(), ['payment_method.data']),
            ]
        );

        $context = [
            'payment_id' => $session->shopify_payment_id,
            'shop' => $session->shop_domain,
            'request_id' => $request->header('Shopify-Request-Id'),
            'api_version' => $request->header('Shopify-Api-Version'),
        ];

        if ($session->wasRecentlyCreated) {
            PaymentLog::info('payment.session.received', $context + [
                'kind' => $session->kind,
                'amount' => $session->amount,
                'currency' => $session->currency,
            ]);
            ProcessPaymentSession::dispatch($session->id);
        } else {
            PaymentLog::info('payment.session.duplicate', $context + ['state' => $session->state->value]);

            // If the first attempt died between insert and dispatch, Shopify's retry heals it.
            // The job is idempotent (CAS on state), so an extra dispatch is harmless.
            if ($session->state === PaymentSessionState::Initiated) {
                ProcessPaymentSession::dispatch($session->id);
            }
        }

        return response()->noContent((int) config('shopify.session_response_status'));
    }
}
