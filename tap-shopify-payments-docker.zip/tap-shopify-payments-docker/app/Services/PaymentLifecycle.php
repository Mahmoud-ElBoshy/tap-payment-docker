<?php

namespace App\Services;

use App\Enums\Outcome;
use App\Enums\PaymentSessionState as S;
use App\Exceptions\CardDecryptionException;
use App\Models\PaymentSession;
use App\Services\Processor\MockCardProcessor;
use App\Services\Processor\ProcessorResult;
use App\Services\Shopify\ShopifyPaymentsApi;
use App\Support\PaymentLog;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Str;

/**
 * Payment session state machine (credit card, per Shopify's "About payment processing").
 *
 *  No 3DS:
 *    INITIATED -> PROCESSING -> RESOLVED | REJECTED
 *
 *  3DS:
 *    INITIATED -> PROCESSING -> PENDING_3DS            paymentSessionRedirect (Shopify shows our page in an iframe)
 *      buyer fails authentication  -> PROCESSING -> REJECTED (AUTHENTICATION_FAILED)
 *      buyer authenticates         -> CONFIRMING         paymentSessionConfirm
 *        Shopify POSTs confirm session URL:
 *          confirmation_result=false -> PROCESSING -> REJECTED (CONFIRMATION_REJECTED)
 *          confirmation_result=true  -> authorize card -> PROCESSING -> RESOLVED | REJECTED
 *
 * Safety rules:
 *  1. Every state change is a compare-and-set UPDATE (WHERE state = :from), so only one worker wins.
 *  2. The decision is persisted BEFORE the final Shopify mutation, so retries never charge twice.
 *  3. Finalization runs under a cache lock and only from PROCESSING -> final state.
 *  4. Shopify mutations are idempotent per id, so re-sending resolve/reject/confirm after a crash is safe.
 */
class PaymentLifecycle
{
    public function __construct(
        private readonly ShopifyPaymentsApi $api,
        private readonly MockCardProcessor $processor,
    ) {
    }

    /** Entry point for the queued job (asynchronous processing after Shopify got its fast 2xx). */
    public function process(int $id): void
    {
        $session = PaymentSession::findOrFail($id);

        if ($session->state === S::Initiated) {
            if (! $this->transition($session, S::Initiated, S::Processing)) {
                PaymentLog::info('payment.claim_lost', $this->ctx($session));

                return;
            }
            $session->refresh();
        }

        match ($session->state) {
            S::Processing => $this->authorizeAndFinalize($session),
            S::Pending3ds => $this->ensureRedirectSent($session),
            S::Confirming => $this->handleConfirmation($session),
            default => PaymentLog::info('payment.skipped', $this->ctx($session)),
        };
    }

    /**
     * The buyer finished the (mock) 3DS challenge inside Shopify's iframe.
     * Returns the URL the buyer must be sent to (in the PARENT window), or null if there is none yet.
     */
    public function complete3ds(string $token, bool $success): ?string
    {
        $session = PaymentSession::where('three_ds_token', $token)->firstOrFail();

        if ($session->state->isFinal()) {
            return $session->buyer_redirect_url ?? $session->confirm_redirect_url;
        }

        if ($session->state === S::Pending3ds) {
            $authentication = json_encode($this->authenticationPayload($success));

            if (! $success) {
                // Authentication failed: reject directly (no paymentSessionConfirm needed).
                $this->transition($session, S::Pending3ds, S::Processing, [
                    'decision' => Outcome::Declined->value,
                    'decline_code' => 'AUTHENTICATION_FAILED',
                    'decline_message' => '3DS authentication failed or was cancelled.',
                    'three_ds_data' => $authentication,
                ]);
                $session->refresh();

                PaymentLog::info('payment.3ds.failed', $this->ctx($session));

                return $this->finalize($session);
            }

            // Move to CONFIRMING BEFORE calling Shopify: the confirm callback can arrive right after the mutation.
            $this->transition($session, S::Pending3ds, S::Confirming, ['three_ds_data' => $authentication]);
            $session->refresh();
            PaymentLog::info('payment.3ds.authenticated', $this->ctx($session));
        }

        if ($session->state === S::Confirming) {
            if ($session->confirm_redirect_url === null) {
                $url = $this->api->confirmPayment($session);
                $session->update(['confirm_redirect_url' => $url]);
                PaymentLog::info('payment.confirm_requested', $this->ctx($session));
            }

            return $session->confirm_redirect_url;
        }

        // PROCESSING with a stored decision (recovery after a crash).
        if ($session->state === S::Processing && $session->decision !== null) {
            return $this->finalize($session);
        }

        return null;
    }

    private function authorizeAndFinalize(PaymentSession $session): void
    {
        if ($session->decision === null) {
            $result = $this->runProcessor($session, false);

            if ($result->outcome === Outcome::Challenge) {
                $this->transition($session, S::Processing, S::Pending3ds, [
                    'three_ds_token' => Str::random(40),
                    'processor_reference' => $result->reference,
                ]);
                $session->refresh();
                $this->ensureRedirectSent($session);

                return;
            }

            $this->storeDecision($session, $result);
        }

        $this->finalize($session);
    }

    /** Shopify delivered its confirmation result (POST to the confirm session URL). */
    private function handleConfirmation(PaymentSession $session): void
    {
        if ($session->confirmation_result === null) {
            PaymentLog::info('payment.confirm_waiting', $this->ctx($session));

            return;
        }

        if ($session->confirmation_result === false) {
            // Shopify no longer wants the payment to proceed (e.g. inventory/discount changed).
            $extra = [
                'decision' => Outcome::Declined->value,
                'decline_code' => 'CONFIRMATION_REJECTED',
                'decline_message' => 'Shopify rejected the confirmation.',
            ];
        } else {
            $result = $this->runProcessor($session, true);
            if ($result->outcome === Outcome::Challenge) {
                $result = ProcessorResult::declined('PROCESSING_ERROR', 'Unexpected 3DS challenge after authentication.');
            }
            $extra = [
                'decision' => $result->outcome->value,
                'decline_code' => $result->code,
                'decline_message' => $result->message,
                'processor_reference' => $result->reference ?? $session->processor_reference,
            ];
        }

        $this->transition($session, S::Confirming, S::Processing, $extra);
        $session->refresh();
        PaymentLog::info('payment.decided', $this->ctx($session) + ['decision' => $session->decision?->value]);

        $this->finalize($session);
    }

    private function storeDecision(PaymentSession $session, ProcessorResult $result): void
    {
        $session->update([
            'decision' => $result->outcome->value,
            'decline_code' => $result->code,
            'decline_message' => $result->message,
            'processor_reference' => $result->reference,
        ]);
        PaymentLog::info('payment.decided', $this->ctx($session) + ['decision' => $result->outcome->value]);
    }

    private function runProcessor(PaymentSession $session, bool $threeDsAuthenticated): ProcessorResult
    {
        try {
            return $this->processor->authorize($session, $threeDsAuthenticated);
        } catch (CardDecryptionException $e) {
            PaymentLog::warning('payment.card_unreadable', $this->ctx($session));

            return ProcessorResult::declined('PROCESSING_ERROR', 'Card data could not be processed.');
        }
    }

    /** Sends paymentSessionRedirect once, so Shopify shows our 3DS page in an iframe. */
    private function ensureRedirectSent(PaymentSession $session): void
    {
        if ($session->redirect_sent_at !== null) {
            return;
        }

        $this->api->redirectPayment($session, route('3ds.show', ['token' => $session->three_ds_token]));
        $session->update(['redirect_sent_at' => now()]);

        PaymentLog::info('payment.redirect_sent', $this->ctx($session));
    }

    /** Resolve or reject on Shopify exactly once. */
    private function finalize(PaymentSession $session): ?string
    {
        return Cache::lock('shopify:finalize:'.$session->shopify_payment_id, 30)->block(10, function () use ($session) {
            $session->refresh();

            if ($session->state->isFinal()) {
                return $session->buyer_redirect_url;
            }

            if ($session->state !== S::Processing || $session->decision === null) {
                return null;
            }

            // Required by Shopify if and only if paymentSessionRedirect was called.
            $authentication = $session->three_ds_data;

            if ($session->decision === Outcome::Approved) {
                $expires = $session->kind === 'authorization'
                    ? now()->addDays((int) config('shopify.authorization_ttl_days'))->toIso8601String()
                    : null;

                $url = $this->api->resolvePayment($session, $expires, $authentication);
                $this->complete($session, S::Resolved, $url);
            } else {
                $url = $this->api->rejectPayment(
                    $session,
                    $session->decline_code ?? 'PROCESSING_ERROR',
                    $session->decline_message ?? 'Payment declined.',
                    $authentication
                );
                $this->complete($session, S::Rejected, $url);
            }

            return $url;
        });
    }

    private function complete(PaymentSession $session, S $final, ?string $url): void
    {
        $this->transition($session, S::Processing, $final, [
            'finalized_at' => now(),
            'buyer_redirect_url' => $url,
            'encrypted_card' => null, // drop card material as soon as it is no longer needed
        ]);

        PaymentLog::info('payment.finalized', ['state' => $final->value] + $this->ctx($session));
    }

    /**
     * 3DS authentication data sent with resolve/reject (PaymentSessionThreeDSecureAuthentication).
     * STUB values: a real app forwards what the 3DS server / processor returned.
     */
    private function authenticationPayload(bool $success): array
    {
        $data = [
            'authenticationFlow' => 'CHALLENGE',
            'version' => 'V2_2',
            'dsTransactionId' => 'mock-ds-'.Str::uuid()->toString(),
        ];

        return ['authenticationData' => $success
            ? $data + ['chargebackLiability' => 'UNKNOWN', 'transStatus' => 'Y']
            // UNKNOWN liability is not allowed with transStatus N/R; a reason is required for N/U/R.
            : $data + ['chargebackLiability' => 'MERCHANT', 'transStatus' => 'N', 'transStatusReason' => '01'],
        ];
    }

    /** Atomic compare-and-set state change. */
    private function transition(PaymentSession $session, S $from, S $to, array $extra = []): bool
    {
        $updated = PaymentSession::whereKey($session->id)
            ->where('state', $from->value)
            ->update(['state' => $to->value, 'updated_at' => now()] + $extra);

        PaymentLog::info('payment.transition', ['from' => $from->value, 'to' => $to->value, 'ok' => $updated === 1] + $this->ctx($session));

        return $updated === 1;
    }

    private function ctx(PaymentSession $session): array
    {
        return [
            'payment_id' => $session->shopify_payment_id,
            'shop' => $session->shop_domain,
            'state' => $session->state->value,
            'amount' => $session->amount,
            'currency' => $session->currency,
        ];
    }
}
