<?php

namespace App\Services\Processor;

use App\Enums\Outcome;

final class ProcessorResult
{
    private function __construct(
        public readonly Outcome $outcome,
        public readonly ?string $reference = null,
        public readonly ?string $code = null,
        public readonly ?string $message = null,
    ) {
    }

    public static function approved(string $reference): self
    {
        return new self(Outcome::Approved, $reference);
    }

    public static function declined(string $code, string $message): self
    {
        return new self(Outcome::Declined, null, $code, $message);
    }

    public static function challenge(string $reference): self
    {
        return new self(Outcome::Challenge, $reference);
    }
}
