<?php

namespace App\Services\Processor;

use App\Exceptions\CardDecryptionException;
use App\Models\PaymentSession;
use App\Models\RefundSession;

/**
 * STUB card processor with deterministic behaviour driven by the card number (pan):
 *   - expired card               -> declined (EXPIRED_CARD)
 *   - ends with 0002             -> declined (CARD_DECLINED)
 *   - 4000000000003220           -> 3DS challenge required (until the buyer authenticated), then approved
 *   - anything else (>=12 digits) -> approved
 *
 * References are derived from the Shopify payment id, which stands in for the idempotency key a real
 * processor would accept: the same session can never produce a second charge.
 */
class MockCardProcessor
{
    public const THREE_DS_CARD = '4000000000003220';

    public function __construct(private readonly CardDecryptor $decryptor)
    {
    }

    /** @throws CardDecryptionException */
    public function authorize(PaymentSession $session, bool $threeDsAuthenticated = false): ProcessorResult
    {
        $card = $this->decryptor->decrypt($session->encrypted_card);
        $pan = preg_replace('/\D/', '', (string) ($card['pan'] ?? ''));

        if (strlen($pan) < 12) {
            throw new CardDecryptionException('Invalid card number.');
        }

        $year = (int) ($card['year'] ?? 0);
        $month = (int) ($card['month'] ?? 0);
        if ($year > 0 && ($year < (int) date('Y') || ($year === (int) date('Y') && $month > 0 && $month < (int) date('n')))) {
            return ProcessorResult::declined('EXPIRED_CARD', 'The card has expired (mock).');
        }

        if (str_ends_with($pan, '0002')) {
            return ProcessorResult::declined('CARD_DECLINED', 'The card was declined by the issuer (mock).');
        }

        $reference = 'mock_auth_'.substr(hash('sha256', $session->shopify_payment_id), 0, 16);

        if ($pan === self::THREE_DS_CARD && ! $threeDsAuthenticated) {
            return ProcessorResult::challenge($reference);
        }

        return ProcessorResult::approved($reference);
    }

    public function refund(PaymentSession $payment, RefundSession $refund): string
    {
        return 'mock_refund_'.substr(hash('sha256', $refund->shopify_refund_id), 0, 16);
    }
}
