<?php

namespace App\Services\Processor;

use App\Exceptions\CardDecryptionException;

/**
 * STUB. Shopify sends the card encrypted with ECIES (payment_method.data: fingerprint, encrypted_message,
 * ephemeral_public_key, tag). A real implementation must, inside a PCI DSS environment:
 *   1. base64-decode encrypted_message and tag, 2. pick the certificate by fingerprint,
 *   3. derive the shared secret from the private key and ephemeral_public_key (ECDH + HKDF-SHA256),
 *   4. verify the HMAC tag, 5. decrypt with AES-256-CTR.
 *
 * Here "encrypted_message" is simply base64(JSON) of the DECRYPTED structure documented by Shopify:
 *   {"type":"card","data":{"full_name":"...","pan":"4242...","month":12,"year":2033,"verification_value":"122"}}
 */
class CardDecryptor
{
    /** @return array{full_name?: string, pan?: string, month?: int, year?: int, verification_value?: string} */
    public function decrypt(?string $encryptedMessage): array
    {
        if ($encryptedMessage === null || $encryptedMessage === '') {
            throw new CardDecryptionException('No encrypted card message.');
        }

        $json = base64_decode($encryptedMessage, true);
        $decoded = $json === false ? null : json_decode($json, true);

        if (! is_array($decoded) || ! is_array($decoded['data'] ?? null)) {
            throw new CardDecryptionException('Card message could not be decoded.');
        }

        return $decoded['data'];
    }
}
