<?php

namespace App\Services;

use App\Enums\Outcome;
use App\Enums\PaymentSessionState;
use App\Enums\RefundSessionState as R;
use App\Models\PaymentSession;
use App\Models\RefundSession;
use App\Services\Processor\MockCardProcessor;
use App\Services\Shopify\ShopifyPaymentsApi;
use App\Support\PaymentLog;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;

/**
 * Post-authorization operation chosen for this case study: REFUND (see docs/NOTES.md).
 * Same safety rules as PaymentLifecycle: CAS transitions, decision persisted before the Shopify mutation,
 * finalize once under a lock.
 */
class RefundLifecycle
{
    public function __construct(
        private readonly ShopifyPaymentsApi $api,
        private readonly MockCardProcessor $processor,
    ) {
    }

    public function process(int $id): void
    {
        $refund = RefundSession::findOrFail($id);

        if ($refund->state === R::Initiated) {
            $claimed = RefundSession::whereKey($refund->id)->where('state', R::Initiated->value)
                ->update(['state' => R::Processing->value, 'updated_at' => now()]) === 1;

            if (! $claimed) {
                PaymentLog::info('refund.claim_lost', $this->ctx($refund));

                return;
            }
            $refund->refresh();
        }

        if ($refund->state !== R::Processing) {
            PaymentLog::info('refund.skipped', $this->ctx($refund));

            return;
        }

        if ($refund->decision === null) {
            $this->decide($refund);
            $refund->refresh();
        }

        $this->finalize($refund);
    }

    /** Validates the refund against the original payment and persists the decision. */
    private function decide(RefundSession $refund): void
    {
        DB::transaction(function () use ($refund) {
            $payment = PaymentSession::where('shopify_payment_id', $refund->payment_ref)->lockForUpdate()->first();

            $decline = null;

            if (! $payment || $payment->state !== PaymentSessionState::Resolved) {
                $decline = 'Original payment not found or not completed.';
            } elseif ($payment->kind !== 'sale') {
                $decline = 'Only captured (sale) payments can be refunded in this demo.';
            } elseif ($payment->currency !== $refund->currency) {
                $decline = 'Currency does not match the original payment.';
            } else {
                $already = (float) RefundSession::where('payment_ref', $refund->payment_ref)
                    ->where('id', '!=', $refund->id)
                    ->where('decision', Outcome::Approved->value)
                    ->sum('amount');

                if ((int) round(($already + (float) $refund->amount) * 100) > (int) round((float) $payment->amount * 100)) {
                    $decline = 'Refund exceeds the refundable amount.';
                }
            }

            if ($decline !== null) {
                $refund->update([
                    'decision' => Outcome::Declined->value,
                    'decline_code' => 'PROCESSING_ERROR',
                    'decline_message' => $decline,
                ]);
            } else {
                $refund->update([
                    'decision' => Outcome::Approved->value,
                    'processor_reference' => $this->processor->refund($payment, $refund),
                ]);
            }

            PaymentLog::info('refund.decided', ['decision' => $refund->decision->value ?? null] + $this->ctx($refund));
        });
    }

    private function finalize(RefundSession $refund): void
    {
        Cache::lock('shopify:finalize-refund:'.$refund->shopify_refund_id, 30)->block(10, function () use ($refund) {
            $refund->refresh();

            if ($refund->state !== R::Processing || $refund->decision === null) {
                return;
            }

            if ($refund->decision === Outcome::Approved) {
                $this->api->resolveRefund($refund);
                $final = R::Resolved;
            } else {
                $this->api->rejectRefund($refund, $refund->decline_code ?? 'PROCESSING_ERROR', $refund->decline_message ?? 'Refund declined.');
                $final = R::Rejected;
            }

            RefundSession::whereKey($refund->id)->where('state', R::Processing->value)
                ->update(['state' => $final->value, 'finalized_at' => now(), 'updated_at' => now()]);

            PaymentLog::info('refund.finalized', ['state' => $final->value] + $this->ctx($refund));
        });
    }

    private function ctx(RefundSession $refund): array
    {
        return [
            'refund_id' => $refund->shopify_refund_id,
            'payment_id' => $refund->payment_ref,
            'shop' => $refund->shop_domain,
            'amount' => $refund->amount,
            'currency' => $refund->currency,
        ];
    }
}
