<?php

namespace App\Services\Shopify;

use App\Models\PaymentSession;
use App\Models\RefundSession;

/**
 * The only place that talks to Shopify's Payments Apps GraphQL API.
 * Every method throws ShopifyApiException on failure so the calling job can retry.
 * (Shopify mutations are idempotent per id: repeating the same mutation is safe.)
 */
interface ShopifyPaymentsApi
{
    /**
     * paymentSessionResolve. $authentication is required if and only if paymentSessionRedirect was called
     * (3DS): ['authenticationData' => [...]].
     * Returns the URL from nextAction, if Shopify gave one.
     */
    public function resolvePayment(PaymentSession $session, ?string $authorizationExpiresAt = null, ?array $authentication = null): ?string;

    /** paymentSessionReject (same $authentication rule as resolve). */
    public function rejectPayment(PaymentSession $session, string $code, string $message, ?array $authentication = null): ?string;

    /** paymentSessionRedirect (3DS): Shopify renders $redirectUrl (absolute HTTPS) in an iframe for the buyer. */
    public function redirectPayment(PaymentSession $session, string $redirectUrl): void;

    /**
     * paymentSessionConfirm (3DS): asks Shopify whether the payment can proceed. Shopify then POSTs the result
     * to our confirm session URL. Returns the URL used to send the buyer back to Shopify.
     */
    public function confirmPayment(PaymentSession $session): ?string;

    public function resolveRefund(RefundSession $refund): void;

    public function rejectRefund(RefundSession $refund, string $code, string $message): void;
}
