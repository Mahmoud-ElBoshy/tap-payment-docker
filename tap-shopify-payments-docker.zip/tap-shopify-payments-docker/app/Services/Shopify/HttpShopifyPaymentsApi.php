<?php

namespace App\Services\Shopify;

use App\Exceptions\ShopifyApiException;
use App\Exceptions\ShopifyUserErrorException;
use App\Models\PaymentSession;
use App\Models\RefundSession;
use Illuminate\Support\Facades\Http;

/**
 * Real client for the Payments Apps API:
 *   POST https://{shop}/payments_apps/api/{version}/graphql.json   (header X-Shopify-Access-Token)
 * Requires an approved Payments Partner app (scopes write_payment_gateways, write_payment_sessions).
 */
class HttpShopifyPaymentsApi implements ShopifyPaymentsApi
{
    private const NEXT_ACTION = 'nextAction { action context { ... on PaymentSessionActionsRedirect { redirectUrl } } }';

    public function resolvePayment(PaymentSession $session, ?string $authorizationExpiresAt = null, ?array $authentication = null): ?string
    {
        $query = 'mutation PaymentSessionResolve($id: ID!, $authorizationExpiresAt: DateTime, $authentication: PaymentSessionThreeDSecureAuthentication) {
            paymentSessionResolve(id: $id, authorizationExpiresAt: $authorizationExpiresAt, authentication: $authentication) {
                paymentSession { id state { ... on PaymentSessionStateResolved { code } } '.self::NEXT_ACTION.' }
                userErrors { field message }
            }
        }';

        $data = $this->call($session->shop_domain, $query, [
            'id' => $session->shopify_gid,
            'authorizationExpiresAt' => $authorizationExpiresAt,
            'authentication' => $authentication,
        ], 'paymentSessionResolve');

        return data_get($data, 'paymentSession.nextAction.context.redirectUrl');
    }

    public function rejectPayment(PaymentSession $session, string $code, string $message, ?array $authentication = null): ?string
    {
        $query = 'mutation PaymentSessionReject($id: ID!, $reason: PaymentSessionRejectionReasonInput!, $authentication: PaymentSessionThreeDSecureAuthentication) {
            paymentSessionReject(id: $id, reason: $reason, authentication: $authentication) {
                paymentSession { id '.self::NEXT_ACTION.' }
                userErrors { field message }
            }
        }';

        $data = $this->call($session->shop_domain, $query, [
            'id' => $session->shopify_gid,
            'reason' => ['code' => $code, 'merchantMessage' => $message],
            'authentication' => $authentication,
        ], 'paymentSessionReject');

        return data_get($data, 'paymentSession.nextAction.context.redirectUrl');
    }

    public function redirectPayment(PaymentSession $session, string $redirectUrl): void
    {
        // Documented requirement: absolute HTTPS URL.
        if (! str_starts_with($redirectUrl, 'https://')) {
            throw new ShopifyApiException('paymentSessionRedirect requires an absolute HTTPS URL (set APP_URL to your public https URL).');
        }

        $query = 'mutation PaymentSessionRedirect($id: ID!, $redirectUrl: URL!) {
            paymentSessionRedirect(id: $id, redirectUrl: $redirectUrl) {
                paymentSession { id }
                userErrors { field message }
            }
        }';

        $this->call($session->shop_domain, $query, [
            'id' => $session->shopify_gid,
            'redirectUrl' => $redirectUrl,
        ], 'paymentSessionRedirect');
    }

    public function confirmPayment(PaymentSession $session): ?string
    {
        $query = 'mutation PaymentSessionConfirm($id: ID!) {
            paymentSessionConfirm(id: $id) {
                paymentSession { id '.self::NEXT_ACTION.' }
                userErrors { field message }
            }
        }';

        $data = $this->call($session->shop_domain, $query, ['id' => $session->shopify_gid], 'paymentSessionConfirm');

        return data_get($data, 'paymentSession.nextAction.context.redirectUrl');
    }

    public function resolveRefund(RefundSession $refund): void
    {
        $query = 'mutation RefundSessionResolve($id: ID!) {
            refundSessionResolve(id: $id) {
                refundSession { id }
                userErrors { field message }
            }
        }';

        $this->call($refund->shop_domain, $query, ['id' => $refund->shopify_gid], 'refundSessionResolve');
    }

    public function rejectRefund(RefundSession $refund, string $code, string $message): void
    {
        $query = 'mutation RefundSessionReject($id: ID!, $reason: RefundSessionRejectionReasonInput!) {
            refundSessionReject(id: $id, reason: $reason) {
                refundSession { id }
                userErrors { field message }
            }
        }';

        $this->call($refund->shop_domain, $query, [
            'id' => $refund->shopify_gid,
            'reason' => ['code' => $code, 'merchantMessage' => $message],
        ], 'refundSessionReject');
    }

    /** @return array<string, mixed> the mutation payload */
    private function call(string $shop, string $query, array $variables, string $root): array
    {
        $url = sprintf('https://%s/payments_apps/api/%s/graphql.json', $shop, config('shopify.api_version'));

        $response = Http::withHeaders(['X-Shopify-Access-Token' => (string) config('shopify.access_token')])
            ->acceptJson()
            ->asJson()
            ->timeout(10)
            ->post($url, ['query' => $query, 'variables' => $variables]);

        if ($response->failed()) {
            throw new ShopifyApiException("Shopify HTTP {$response->status()} on {$root}");
        }

        $json = $response->json();

        // GraphQL answers 200 even for errors (THROTTLED, ACCESS_DENIED, INTERNAL_SERVER_ERROR...).
        if (! empty($json['errors'])) {
            throw new ShopifyApiException("Shopify GraphQL errors on {$root}: ".json_encode($json['errors']));
        }

        $payload = $json['data'][$root] ?? [];

        if (! empty($payload['userErrors'])) {
            throw new ShopifyUserErrorException("Shopify userErrors on {$root}: ".json_encode($payload['userErrors']));
        }

        return $payload;
    }
}
