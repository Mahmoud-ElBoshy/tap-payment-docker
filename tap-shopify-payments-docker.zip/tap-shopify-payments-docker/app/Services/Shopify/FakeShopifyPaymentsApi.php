<?php

namespace App\Services\Shopify;

use App\Models\PaymentSession;
use App\Models\RefundSession;
use App\Support\PaymentLog;

/**
 * STUBBED Shopify GraphQL responses (SHOPIFY_API_DRIVER=fake, the default for this exercise, and tests).
 * It records every call so tests can assert the exact mutation order and arguments.
 */
class FakeShopifyPaymentsApi implements ShopifyPaymentsApi
{
    /** @var list<array{0: string, 1: array}> */
    public array $calls = [];

    public function resolvePayment(PaymentSession $session, ?string $authorizationExpiresAt = null, ?array $authentication = null): ?string
    {
        $this->record('resolvePayment', ['id' => $session->shopify_gid, 'expires' => $authorizationExpiresAt, 'authentication' => $authentication]);

        return $authentication ? null : 'https://'.$session->shop_domain.'/fake-return/'.$session->shopify_payment_id;
    }

    public function rejectPayment(PaymentSession $session, string $code, string $message, ?array $authentication = null): ?string
    {
        $this->record('rejectPayment', ['id' => $session->shopify_gid, 'code' => $code, 'authentication' => $authentication]);

        return 'https://'.$session->shop_domain.'/fake-return/'.$session->shopify_payment_id;
    }

    public function redirectPayment(PaymentSession $session, string $redirectUrl): void
    {
        $this->record('redirectPayment', ['id' => $session->shopify_gid, 'url' => $redirectUrl]);
    }

    public function confirmPayment(PaymentSession $session): ?string
    {
        $this->record('confirmPayment', ['id' => $session->shopify_gid]);

        return 'https://'.$session->shop_domain.'/fake-confirm-return/'.$session->shopify_payment_id;
    }

    public function resolveRefund(RefundSession $refund): void
    {
        $this->record('resolveRefund', ['id' => $refund->shopify_gid]);
    }

    public function rejectRefund(RefundSession $refund, string $code, string $message): void
    {
        $this->record('rejectRefund', ['id' => $refund->shopify_gid, 'code' => $code]);
    }

    /** @return list<string> */
    public function callNames(): array
    {
        return array_map(fn ($c) => $c[0], $this->calls);
    }

    private function record(string $name, array $args): void
    {
        $this->calls[] = [$name, $args];
        PaymentLog::info('shopify.fake.'.$name, $args);
    }
}
