<?php

namespace App\Providers;

use App\Services\Shopify\FakeShopifyPaymentsApi;
use App\Services\Shopify\HttpShopifyPaymentsApi;
use App\Services\Shopify\ShopifyPaymentsApi;
use Illuminate\Support\ServiceProvider;

class ShopifyServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        $this->app->singleton(ShopifyPaymentsApi::class, function () {
            return config('shopify.api_driver') === 'http'
                ? new HttpShopifyPaymentsApi()
                : new FakeShopifyPaymentsApi();
        });
    }
}
