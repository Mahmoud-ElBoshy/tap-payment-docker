<?php

namespace App\Jobs;

use App\Services\PaymentLifecycle;
use App\Support\PaymentLog;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use App\Exceptions\ShopifyUserErrorException;
use Throwable;

class ProcessPaymentSession implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public int $tries = 18;

    public function __construct(public readonly int $paymentSessionId)
    {
    }

    /** @return list<int> seconds between retries */
    public function backoff(): array
    {
        // Shopify's recommended schedule: 0s, 5s, 10s, 30s, 45s, 1m, 2m, 5m, 12m, 38m, 1h, 2h, then 4h x 5.
        return [5, 10, 30, 45, 60, 120, 300, 720, 2280, 3600, 7200, 14400, 14400, 14400, 14400, 14400];
    }

    public function handle(PaymentLifecycle $lifecycle): void
    {
        try {
            $lifecycle->process($this->paymentSessionId);
        } catch (ShopifyUserErrorException $e) {
            // userErrors (e.g. conflicting mutation) will not fix themselves: do not retry.
            $this->fail($e);
        }
    }

    public function failed(Throwable $e): void
    {
        PaymentLog::error('payment.job_failed', ['session_id' => $this->paymentSessionId, 'error' => $e->getMessage()]);
    }
}
