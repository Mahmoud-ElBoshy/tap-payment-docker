<?php

namespace App\Exceptions;

use RuntimeException;

class CardDecryptionException extends RuntimeException
{
}
