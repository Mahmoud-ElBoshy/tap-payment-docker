<?php

namespace App\Exceptions;

/**
 * Shopify answered with userErrors (e.g. a conflicting mutation on a finalized session).
 * Unlike network/5xx failures these will not fix themselves, so jobs do not retry them.
 */
class ShopifyUserErrorException extends ShopifyApiException
{
}
