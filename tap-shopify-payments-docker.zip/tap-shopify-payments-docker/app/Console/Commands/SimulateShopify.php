<?php

namespace App\Console\Commands;

use App\Enums\PaymentSessionState;
use App\Models\PaymentSession;
use App\Models\RefundSession;
use App\Services\PaymentLifecycle;
use Illuminate\Console\Command;
use Illuminate\Contracts\Http\Kernel;
use Illuminate\Http\Request;
use Illuminate\Support\Str;

/**
 * Acts as Shopify and as the buyer, against this backend:
 *  - POSTs payment session / confirm session / refund session requests shaped like Shopify's request reference
 *  - plays the buyer on the 3DS page (inside Shopify's iframe, here: a direct call)
 * The app answers through the STUBBED Shopify GraphQL client (FakeShopifyPaymentsApi), so no Payments Partner
 * approval or live store is needed.
 *
 * Needs the queue worker (make up / php artisan queue:work): processing is asynchronous, as in production.
 */
class SimulateShopify extends Command
{
    protected $signature = 'shopify:simulate
        {scenario : approve | decline | 3ds-success | 3ds-fail | 3ds-confirm-rejected | refund | duplicate}
        {--amount=25.00 : Payment amount}
        {--refund=10.00 : Refund amount (refund scenario)}
        {--wait=20 : Seconds to wait for the async worker}';

    protected $description = 'Simulate Shopify payment-session requests against this backend';

    private const CARDS = [
        'approve' => '4242424242424242',
        'decline' => '4000000000000002',
        '3ds-success' => '4000000000003220',
        '3ds-fail' => '4000000000003220',
        '3ds-confirm-rejected' => '4000000000003220',
        'refund' => '4242424242424242',
        'duplicate' => '4242424242424242',
    ];

    public function handle(PaymentLifecycle $lifecycle): int
    {
        $scenario = (string) $this->argument('scenario');
        if (! isset(self::CARDS[$scenario])) {
            $this->error('Unknown scenario. Use: '.implode(', ', array_keys(self::CARDS)));

            return self::FAILURE;
        }

        $id = 'sim-'.Str::lower(Str::random(8));
        $this->info("Scenario: {$scenario}  (payment id: {$id})");

        $status = $this->sendPayment($id, self::CARDS[$scenario], (string) $this->option('amount'));
        $this->line("-> POST /shopify/payment_session = HTTP {$status}");

        if ($scenario === 'duplicate') {
            foreach ([2, 3] as $n) {
                $this->line("-> duplicate delivery #{$n} = HTTP ".$this->sendPayment($id, self::CARDS[$scenario], (string) $this->option('amount')));
            }
        }

        $session = $this->waitFor($id, fn ($s) => $s->state === PaymentSessionState::Pending3ds || $s->state->isFinal());
        if (! $session) {
            $this->error('Timed out. Is the queue worker running? (make up / php artisan queue:work)');

            return self::FAILURE;
        }

        if ($session->state === PaymentSessionState::Pending3ds) {
            $this->line('-> app called paymentSessionRedirect; Shopify would show this page in an iframe: '.route('3ds.show', $session->three_ds_token));
            $authenticate = $scenario !== '3ds-fail';
            $this->line('-> simulating buyer: '.($authenticate ? 'authenticates' : 'fails authentication'));
            $lifecycle->complete3ds($session->three_ds_token, $authenticate);
            $session->refresh();

            if ($session->state === PaymentSessionState::Confirming) {
                $confirm = $scenario !== '3ds-confirm-rejected';
                $this->line('-> app called paymentSessionConfirm; Shopify answers on the confirm session URL: confirmation_result='.($confirm ? 'true' : 'false'));
                $status = $this->post('/shopify/confirm_session', [
                    'id' => $id,
                    'gid' => "gid://shopify/PaymentSession/{$id}",
                    'confirmation_result' => $confirm,
                ]);
                $this->line("-> POST /shopify/confirm_session = HTTP {$status}");

                $session = $this->waitFor($id, fn ($s) => $s->state->isFinal());
                if (! $session) {
                    $this->error('Timed out waiting for the confirmation to be processed.');

                    return self::FAILURE;
                }
            }
        }

        $this->line("Final payment state: {$session->state->value}");

        if ($scenario === 'refund') {
            $this->simulateRefund($id);
        }

        $this->printShopifyCalls($id);

        return self::SUCCESS;
    }

    private function simulateRefund(string $paymentId): void
    {
        $refundId = 'simref-'.Str::lower(Str::random(6));
        $status = $this->post('/shopify/refund_session', [
            'id' => $refundId,
            'gid' => "gid://shopify/RefundSession/{$refundId}",
            'payment_id' => $paymentId,
            'amount' => (string) $this->option('refund'),
            'currency' => 'USD',
            'test' => true,
            'merchant_locale' => 'en',
            'proposed_at' => now()->toIso8601String(),
        ]);
        $this->line("-> POST /shopify/refund_session = HTTP {$status} (Shopify expects 201)");

        $deadline = time() + (int) $this->option('wait');
        do {
            $refund = RefundSession::where('shopify_refund_id', $refundId)->first();
            if ($refund?->state->isFinal()) {
                break;
            }
            sleep(1);
        } while (time() < $deadline);

        $this->line('Final refund state: '.($refund?->state->value ?? 'unknown'));
    }

    /** Payload shaped like "Credit card payment" in Shopify's request reference. */
    private function sendPayment(string $id, string $pan, string $amount): int
    {
        $card = ['type' => 'card', 'data' => [
            'full_name' => 'Percy Parker', 'pan' => $pan, 'month' => 12, 'year' => (int) date('Y') + 3, 'verification_value' => '122',
        ]];

        return $this->post('/shopify/payment_session', [
            'id' => $id,
            'gid' => "gid://shopify/PaymentSession/{$id}",
            'group' => 'sim-group',
            'session_id' => 'sim-session',
            'amount' => $amount,
            'currency' => 'USD',
            'test' => true,
            'merchant_locale' => 'en',
            'payment_method' => ['type' => 'credit_card', 'data' => [
                'fingerprint' => 'sim-fingerprint',
                // STUB: real messages are ECIES-encrypted; here it is base64(JSON of the decrypted structure).
                'encrypted_message' => base64_encode(json_encode($card)),
                'ephemeral_public_key' => 'sim-ephemeral-key',
                'tag' => 'sim-tag',
                'moto' => false,
            ]],
            'proposed_at' => now()->toIso8601String(),
            'customer' => ['email' => 'buyer@example.com', 'locale' => 'en'],
            'kind' => 'sale',
            'client_details' => ['ip_address' => '127.0.0.1', 'user_agent' => 'shopify-simulator', 'accept_language' => 'en-US'],
        ]);
    }

    /** Sends a request with the headers Shopify sends (no HMAC: Shopify authenticates with mTLS). */
    private function post(string $uri, array $payload): int
    {
        $server = [
            'CONTENT_TYPE' => 'application/json',
            'HTTP_ACCEPT' => 'application/json',
            'HTTP_SHOPIFY_SHOP_DOMAIN' => (string) config('shopify.shop_domain'),
            'HTTP_SHOPIFY_REQUEST_ID' => (string) Str::uuid(),
            'HTTP_SHOPIFY_API_VERSION' => (string) config('shopify.api_version'),
        ];

        // Stand-in for the web server that terminates mTLS.
        if (config('shopify.mtls') === 'proxy') {
            $server['SSL_CLIENT_VERIFY'] = 'SUCCESS';
        }

        $request = Request::create($uri, 'POST', [], [], [], $server, json_encode($payload));

        return app(Kernel::class)->handle($request)->getStatusCode();
    }

    private function waitFor(string $id, callable $done): ?PaymentSession
    {
        $deadline = time() + (int) $this->option('wait');
        do {
            $session = PaymentSession::where('shopify_payment_id', $id)->first();
            if ($session && $done($session)) {
                return $session;
            }
            sleep(1);
        } while (time() < $deadline);

        return null;
    }

    /** Shows what the app sent to the stubbed Shopify GraphQL API for this payment (from the payments log). */
    private function printShopifyCalls(string $paymentId): void
    {
        $file = storage_path('logs/payments.log');
        if (! is_file($file)) {
            return;
        }

        $this->newLine();
        $this->info('Stubbed Shopify GraphQL calls made by the app:');
        foreach (file($file, FILE_IGNORE_NEW_LINES) as $line) {
            if (str_contains($line, 'shopify.fake.') && str_contains($line, $paymentId)) {
                $row = json_decode($line, true);
                $this->line('  '.str_replace('shopify.fake.', '', $row['message'] ?? '').' '.json_encode($row['context'] ?? []));
            }
        }
    }
}
