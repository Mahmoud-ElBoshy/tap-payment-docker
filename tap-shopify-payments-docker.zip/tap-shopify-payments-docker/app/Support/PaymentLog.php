<?php

namespace App\Support;

use Illuminate\Support\Facades\Log;
use Monolog\Formatter\JsonFormatter;
use Psr\Log\LoggerInterface;

/**
 * Structured (JSON-per-line) lifecycle logging in storage/logs/payments.log.
 * Never pass card data or tokens in $context.
 */
final class PaymentLog
{
    private static ?LoggerInterface $logger = null;

    public static function info(string $event, array $context = []): void
    {
        self::logger()->info($event, $context);
    }

    public static function warning(string $event, array $context = []): void
    {
        self::logger()->warning($event, $context);
    }

    public static function error(string $event, array $context = []): void
    {
        self::logger()->error($event, $context);
    }

    private static function logger(): LoggerInterface
    {
        return self::$logger ??= Log::build([
            'driver' => 'single',
            'path' => storage_path('logs/payments.log'),
            'level' => 'debug',
            'formatter' => JsonFormatter::class,
        ]);
    }
}
