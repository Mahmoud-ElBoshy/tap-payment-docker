# Contract check against Shopify's documentation

The implementation was cross-checked against the three reference pages from the brief
(processing, request reference, Payments Apps API) plus "Implementation considerations" and the mutation/enum pages
they link to. This file lists what was verified and what was corrected.

## Corrections made after reading the docs

| Area | First draft | Documented behaviour | Now |
|---|---|---|---|
| Request authentication | HMAC header (`Shopify-Hmac-Sha256`) | Mutual TLS; Shopify sends `Shopify-Shop-Domain`, `Shopify-Request-Id`, `Shopify-Api-Version` | `VerifyShopifyRequest`: mTLS result from the web server (`SSL_CLIENT_VERIFY`), shop allow-list; nginx sketch in `docs/mtls-nginx.conf.example` |
| GraphQL endpoint | `/admin/api/{v}/graphql.json` | `https://{shop}/payments_apps/api/{v}/graphql.json` | `HttpShopifyPaymentsApi` |
| API version | 2025-10 | 2026-10 latest | default `2026-10` (configurable) |
| 3DS flow | redirect -> resolve/reject | redirect -> **paymentSessionConfirm** -> Shopify POSTs the **confirm session URL** -> resolve/reject | new CONFIRMING state, `ConfirmSessionController`, `confirmPayment()` |
| 3DS data on finalization | none | `authentication` is required on resolve/reject iff redirect was called | `three_ds_data` stored and sent |
| Rejection reasons | CARD_DECLINED, PROCESSING_ERROR, AUTHENTICATION_FAILED | also `CONFIRMATION_REJECTED` when `confirmation_result=false` | handled; `EXPIRED_CARD` added to the mock |
| Refund response | 200 | HTTP **201**, empty body | 201 |
| Payment session response | 200 | any 2xx, empty body (brief: 200) | 200 (configurable) |
| 3DS page | full-page redirect | Shopify shows it in an **iframe**; buyer is sent back via the **parent** window | `threeds-redirect` view |
| redirectUrl | any URL | absolute **HTTPS** URL | enforced by the real client |
| Mutation retries | "userErrors on resend" | mutations are idempotent per id; only conflicting mutations return userErrors | resend is safe; userErrors are non-retryable (`ShopifyUserErrorException`) |
| Retry policy | 5 tries | up to 18 retries over 24h (0s, 5s, 10s, 30s, 45s, 1m, 2m, 5m, 12m, 38m, 1h, 2h, then 4h x5) | jobs use that schedule |
| Request fields | minimal | `group`, `session_id`, `merchant_locale`, `proposed_at`, `payment_method.data.{fingerprint,encrypted_message,ephemeral_public_key,tag}`, `client_details` for 3DS | validated; simulator sends them |
| Decrypted card | `{"number": ...}` | `{"type":"card","data":{"full_name","pan","month","year","verification_value"}}` | stub decryptor uses this structure |
