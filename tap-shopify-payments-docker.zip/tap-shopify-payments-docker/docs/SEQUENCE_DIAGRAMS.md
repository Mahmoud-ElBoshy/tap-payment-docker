# Sequence diagrams

Based on Shopify's "About payment processing" (credit card payments, with and without 3-D Secure).

## 1. Credit card payment without 3DS

```mermaid
sequenceDiagram
    autonumber
    participant B as Buyer
    participant S as Shopify
    participant A as App (Laravel)
    participant Q as Queue worker
    participant P as Mock processor

    B->>S: Pay with credit card
    S->>A: POST /shopify/payment_session (mTLS, Shopify-Request-Id)
    A->>A: INSERT session (UNIQUE payment id) = INITIATED
    A-->>S: 200 (empty body)
    A->>Q: dispatch ProcessPaymentSession
    Q->>Q: CAS INITIATED -> PROCESSING
    Q->>P: authorize(card) (stub decryption)
    P-->>Q: approved / declined
    Q->>Q: persist decision
    alt approved
        Q->>S: paymentSessionResolve (GraphQL)
        Q->>Q: PROCESSING -> RESOLVED
    else declined
        Q->>S: paymentSessionReject (GraphQL)
        Q->>Q: PROCESSING -> REJECTED
    end
    S-->>B: order confirmed / payment error
```

## 2. Credit card payment with 3DS (redirect -> confirm -> resolve/reject)

```mermaid
sequenceDiagram
    autonumber
    participant B as Buyer (iframe)
    participant S as Shopify
    participant A as App (Laravel)
    participant Q as Queue worker
    participant P as Mock processor

    S->>A: POST /shopify/payment_session
    A-->>S: 200
    A->>Q: dispatch ProcessPaymentSession
    Q->>P: authorize(card)
    P-->>Q: 3DS challenge required
    Q->>Q: PROCESSING -> PENDING_3DS
    Q->>S: paymentSessionRedirect(redirectUrl = https://app/3ds/{token})
    S-->>B: render /3ds/{token} in an iframe
    B->>A: POST /3ds/{token} (authenticate or fail)
    alt authentication failed
        A->>S: paymentSessionReject(AUTHENTICATION_FAILED, authentication data)
        A->>A: -> REJECTED
    else authenticated
        A->>A: PENDING_3DS -> CONFIRMING
        A->>S: paymentSessionConfirm
        S-->>A: nextAction.redirectUrl
        A-->>B: page navigates the PARENT window to that URL
        S->>A: POST /shopify/confirm_session {confirmation_result}
        A-->>S: 200
        A->>Q: dispatch ProcessPaymentSession
        alt confirmation_result = false
            Q->>S: paymentSessionReject(CONFIRMATION_REJECTED, authentication data)
        else confirmation_result = true
            Q->>P: authorize(card, 3DS authenticated)
            P-->>Q: approved / declined
            Q->>S: paymentSessionResolve / Reject (+ authentication data)
        end
        Q->>Q: PROCESSING -> RESOLVED | REJECTED
    end
```

## 3. Refund (post-authorization operation)

```mermaid
sequenceDiagram
    participant S as Shopify
    participant A as App
    participant Q as Queue worker
    S->>A: POST /shopify/refund_session
    A-->>S: 201 (empty body)
    A->>Q: dispatch ProcessRefundSession
    Q->>Q: validate vs original payment (locked row), persist decision
    alt valid
        Q->>S: refundSessionResolve
    else invalid / over-refund
        Q->>S: refundSessionReject(PROCESSING_ERROR)
    end
```
