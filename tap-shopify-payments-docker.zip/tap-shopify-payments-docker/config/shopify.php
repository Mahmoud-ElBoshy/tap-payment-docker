<?php

return [
    // "fake" = stubbed Shopify GraphQL responses (default for this exercise, no Partner approval needed).
    // "http" = real Payments Apps API client (https://{shop}/payments_apps/api/{version}/graphql.json).
    'api_driver' => env('SHOPIFY_API_DRIVER', 'fake'),

    'shop_domain' => env('SHOPIFY_SHOP_DOMAIN'),
    'access_token' => env('SHOPIFY_ACCESS_TOKEN'),
    'api_version' => env('SHOPIFY_API_VERSION', '2026-10'),

    // How incoming Shopify requests are authenticated.
    // Shopify uses mutual TLS (mTLS) for payment/refund/confirm session requests, terminated at the web server.
    //   off   = simulation / local dev (no client certificate available)
    //   proxy = require the web server to report a verified Shopify client certificate (SSL_CLIENT_VERIFY=SUCCESS)
    'mtls' => env('SHOPIFY_MTLS', 'off'),

    // Status returned by the payment session endpoint (docs: any 2xx for credit card; the brief says 200).
    'session_response_status' => (int) env('SHOPIFY_SESSION_RESPONSE_STATUS', 200),

    // Authorization-only payments: how long the authorization is valid.
    'authorization_ttl_days' => 7,
];
